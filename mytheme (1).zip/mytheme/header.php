<header lang="zxx">
	
<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>আপনকথা</title>
        <meta name ="desscription" content="Support our NGO's educational mission in Alipurduar - striving to offer equal educational opportunities for all. Explore indigenous literature from India and various tribes like Garo, Khasi, Jayantia, and other North-Eastern tribes."/>
        <meta name="description" content="আলিপুরদুয়ারের একটি এনজিও, শিক্ষায় সম্প্রেরণ করে - সমস্তের জন্য সমান শিক্ষামূল্য প্রদানের জন্য আমাদের এনজিওর মিশনে যোগ দিন।.ভারত থেকে উপজাতীয় সাহিত্য এবং গারো, খাসি, জয়ন্তিয়া, মেঘালয়ের মতো উত্তর-পূর্ব উপজাতি, এটি বিভিন্ন জাতগুলির একটি সমৃদ্ধ সংগ্রহ। #Tribal Literature from India and North East Tribes like Garo, Khasi, Jayantia, Meghalaya,This is a rich collection of variety of generes #aponkotha #apon katha "/>
        <meta property="og:description" content="A NGO of Alipurduar,empowering communities through education - Join our NGOs mission to provide equal educational opportunities for all.Bridging the education gap - Support our NGO efforts in providing inclusive education for all communities." />
        <meta property="og:title" content="Aponkotha আপন কথা:  alipurduar-ngo | aponkotha.com"/>
        <meta property="og:type" content="ngo website" />
       <meta property="og:url"content="https://aponkotha.com/"/>
        <meta name="keywords" content="aponkotha-alipurduar,aponkotha,tribes, tribal literature, aponkothango, aponkotha,Alipurduar, Alipurduar-ngo,ngo full form,ngo,ngo near me,ngo in india,ngo website,Aponkotha,aponkotha,aponkotha-ngo,aponkotha ngo,আপন কথা: অবনীন্দ্রনাথ ঠাকুর,Apon Katha - Abanindranath Tagore,Apon Kotha,আপনকথা,ngo in Alipurduar,Alipurduar ngo,Child Rights and You (CRY)">
        <meta http-equiv="refresh" content="1800">
        
        <meta property="description" content="A NGO of Alipurduar,empowering communities through education - Join our NGO's mission to provide equal educational opportunities for all.Bridging the education gap - Support our NGO's efforts in providing inclusive education for all communities."</meta>
        <meta property="og:image" content="https://aponkotha.com/%e0%a6%86%e0%a6%aa%e0%a6%a8%e0%a6%95%e0%a6%a5%e0%a6%be-%e0%a6%ac%e0%a6%87-%e0%a6%ad%e0%a6%be%e0%a6%a8%e0%a7%8d%e0%a6%a1%e0%a6%be%e0%a6%b0/" />
        <meta property="og:image" content="<?php echo get_template_directory_uri();?>/images/logo.jpeg"/>
        <meta property="og:image:width" content="300" />
        <meta property="og:image:height" content="300" />
        <meta property="og:tag" content="aponkotha alipurduar"/>
        <meta name="author" content="aponkotha,আপনকথা">
       <meta name="google-site-verification" content="3TPswDJuAUsrKyktCf1Js6mgTZbVeqFQ-Oba1Us_jiE" />
       <meta name="cname" content="zrrfhaonj2wj">
       <meta name="cname" content="gv-iard2zsjinprfh.dv.googlehosted.com">
       <meta name="generator" content="wordpress6.6"/>
               <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-VEKB3S7FCM"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'G-VEKB3S7FCM');
        </script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "ArchiveOrganization",
          "name": "Aponkotha",
          "image": "https://aponkotha.com/wp-content/themes/mytheme/images/logo.jpeg",
          "@id": "",
          "url": "https://aponkotha.com/aaponkotha",
          "telephone": "9832563014",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Boi Mahal,Buxa Fider Road Alipurduar",
            "addressLocality": "Alipurduar",
            "postalCode": "736122",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 26.496445,
            "longitude": 89.5271164
          },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday",
              "Sunday"
            ],
            "opens": "00:00",
            "closes": "23:59"
          },
          "sameAs": "https://www.facebook.com/boimahal.apd?mibextid=ZbWKwL",
          "department": {
            "@type": "ArchiveOrganization",
            "name": "",
            "image": "",
            "telephone": "" 
          }
        }
        </script>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
	<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/themify-icons.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
	
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- <link rel="manifest" href="site.webmanifest"> -->
    	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <!-- Place favicon.ico in the root directory -->
		<nav class="navbar navbar-expand-lg navbar-light bg-warning navbar-expand-sm  justify-content-around mainnavv" style="margin-left: 111px;
    margin-right: 109px;width:88.5%;">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
			<span class="badge badge-danger">মেনু</span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			<div class=" my-nav">
			 <ul class="navbar-nav w-100 d-flex justify-content-around">
    			<li class="nav-item ">
                 <a class="nav-item nav-link" href="/aaponkotha" rel="dofollow" hreflang="bn">মূলপাতা</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" hreflang="bn" href="https://aponkotha.com/%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%9a%e0%a6%bf%e0%a6%a4%e0%a6%bf/">পরিচিতি</a>
                 </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     কার্যক্রম 
                    </a>
                     
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item"  rel="canonical" href="https://aponkotha.com/%e0%a6%95%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%95%e0%a7%8d%e0%a6%b0%e0%a6%ae/"> সাম্প্রতিক কার্যক্রম </a>
                      <a class="dropdown-item"  rel="canonical" href="https://aponkotha.com/%e0%a6%86%e0%a6%97%e0%a6%be%e0%a6%ae%e0%a7%80-%e0%a6%95%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%95%e0%a7%8d%e0%a6%b0%e0%a6%ae/">আগামী কার্যক্রম</a>
                      
                 
            				<!--<//?php wp_nav_menu(array('theme_location'=>'primary-menu','menu_class'=>'my-nav '))?>-->
            	    </div>
            	</li>
            	<li class="nav-item">
                 <a class="nav-item nav-link"  rel="canonical" href="https://aponkotha.com/%e0%a6%97%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%b2%e0%a6%be%e0%a6%b0%e0%a6%bf/" rel="dofollow">গ্যালারি</a>
                </li>
            	<li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 মিডিয়া
                                </a>
                                 
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item"  rel="canonical" href="https://aponkotha.com/%e0%a6%ae%e0%a7%81%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a6%bf%e0%a6%a4-%e0%a6%ae%e0%a6%bf%e0%a6%a1%e0%a6%bf%e0%a6%af%e0%a6%bc%e0%a6%be/">মুদ্রিত মিডিয়া</a>
                                  <a class="dropdown-item"  rel="canonical"  href="https://aponkotha.com/%e0%a6%87%e0%a6%b2%e0%a7%87%e0%a6%95%e0%a6%9f%e0%a7%8d%e0%a6%b0%e0%a6%a8%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%b8-%e0%a6%ae%e0%a6%bf%e0%a6%a1%e0%a6%bf%e0%a6%af%e0%a6%bc%e0%a6%be/">ইলেকট্রনিক্স মিডিয়া                               </a>
                                  
                             
                        				
                        	    </div>
                </li>
                <li class="nav-item dropdown ">
                 <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">যোগাযোগ</a>
                 
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item"  rel="canonical" href="https://aponkotha.com/%e0%a6%af%e0%a7%8b%e0%a6%97%e0%a6%be%e0%a6%af%e0%a7%8b%e0%a6%97/">আপনি আমাদের সাথে যোগাযোগ করতে চান</a>
                                  <a class="dropdown-item"  rel="canonical"  href="https://aponkotha.com/%e0%a6%86%e0%a6%ae%e0%a6%be%e0%a6%a6%e0%a7%87%e0%a6%b0-%e0%a6%a0%e0%a6%bf%e0%a6%95%e0%a6%be%e0%a6%a8%e0%a6%be/">আমাদের ঠিকানা      </a>
                                  
                                <a class="dropdown-item" href="https://aponkotha.com/wp-admin/admin-ajax.php?action=frm_forms_preview&form=boi-sangrhasala"target="_blank">বই সংগ্রহশালা থেকে তথ্য পেতে-আমাদের সাথে যোগাযোগ করতে চান</a>

                        				
                        	    </div>
                 
                </li>
                
                <li class="nav-item ">
                 <a class="nav-item nav-link" rel="canonical" hreflang="bn" href="https://aponkotha.com/%e0%a6%a6%e0%a6%be%e0%a6%a8-%e0%a6%95%e0%a6%b0%e0%a7%81%e0%a6%a8/" rel="dofollow">দান করুন</a>
                </li>
                </ul>
		</div>
	</div>
	</nav>
	</header>

	
	<!-- CSS here -->
    
	
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<!--contact js-->
    <script src="<?php echo get_template_directory_uri();?>/js/contact.js"></script>
    <!--<script src="<//?php echo get_template_directory_uri();?>/js/jquery.ajaxchimp.min.js"></script>-->
    <script src="<?php echo get_template_directory_uri();?>/js/jquery.form.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/jquery.validate.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/mail-script.js"></script>
    <!--<script src="<//?php echo get_template_directory_uri();?>/js/datahandel.js"></script>-->
    <script src="<?php echo get_template_directory_uri();?>/js/main.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/media.js"></script>
	<script src="<?php echo get_template_directory_uri();?>/js/ajax-form.js"></script>
	
	</section>
    
