<!DOCTYPE html>
<html lang="en">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name ="desscription" content="Support our NGO's educational mission in Alipurduar - striving to offer equal educational opportunities for all. Explore indigenous literature from India and various tribes like Garo, Khasi, Jayantia, and other North-Eastern tribes."/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css">
     <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/bootstrap.min.css">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <body>
        <?php get_header();?>
        <div class="container container-fluid">
            <div class="row container container-fluid">
                <h4 class="text-primary" style="margin-left: 41px; margin-top: 14px;"><?php the_title();?></h4><br><br>
            </div>
            <div class="row container container-fluid">
                  <div class ="col-md-8 col-sm-12 mx-auto card card-body">
                <?php the_content();?>
            </div>
            </div>
          
            
        </div>
        
        <?php get_footer();?>
    </body>
</html>