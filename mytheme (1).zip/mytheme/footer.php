<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/themify-icons.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ajaxchimp/1.3.0/jquery.ajaxchimp.langs.min.js" integrity="sha512-efX911iepPBIFOBHk0LZjUeJxtKHctsdUjfwR8XIYNstdX01tDgEgRu7y2I7mYyCDNgeCX+ZiU3zy7mxCa9dHw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<footer class="footer">
        <div class="footer_top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-md-6 col-lg-4 ">
                        <div class="footer_widget">
                            <div class="footer_logo">
                                <a href="#home">
                                    <img  width="40px" height="40px" src="<?php echo get_template_directory_uri(); ?>/images/logo.jpeg" alt="">
                                </a>
                            </div>
                            <div class="socail_links">
                                <ul>
                                    <li>
                                        <a href="https://www.facebook.com/boimahal.apd?mibextid=ZbWKwL">
                                            <i class="ti-facebook"></i>
                                        </a>
                                    </li>
                                    <!--<li>-->
                                    <!--    <a href="#">-->
                                    <!--        <i class="ti-twitter-alt"></i>-->
                                    <!--    </a>-->
                                    <!--</li>-->
                                    <!--<li>-->
                                    <!--    <a href="#">-->
                                    <!--        <i class="fa fa-dribbble"></i>-->
                                    <!--    </a>-->
                                    <!--</li>-->
                                    <!--<li>-->
                                    <!--    <a href="#">-->
                                    <!--        <i class="fa fa-instagram"></i>-->
                                    <!--    </a>-->
                                    <!--</li>-->
                                </ul>
                                <p class="text-dark">ডুয়ার্সের পিছিয়ে পরা আদিবাসী শিশু-কিশোরদের মধ্যে বইয়ের মাধ্যমে শিক্ষার আলো ছড়িয়ে দিতে আমাদের চেষ্টার অংশ হতে নতুন-পুরানো বই বা এই স্ক্যান করে অর্থ দান করতে পারেন।</p>
                                <div class="col-md-4">
                                    <div class="thumbnail">
                                        <!--<img src="<?php echo get_template_directory_uri(); ?>/images/apbaner.jpg" alt="alokbartika" class="img-thumbnail img-responsive">-->
                                        <img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri();?>/images/qr.jpeg" alt="aponkotha">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-2 col-md-6 col-lg-4">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                                Navigation
                            </h3>
                            <ul class="links">
                            <li class "nav-item">
                            <a class="nav-item nav-link" href="/aponkotha">মূলপাতা</a>
                            </li>
                                        <li class="nav-item ">
                                <a class="nav-link" href="https://aponkotha.com/%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%9a%e0%a6%bf%e0%a6%a4%e0%a6%bf/">পরিচিতি</a>
                             </li>
                              <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 কার্যক্রম 
                                </a>
                                 
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="https://aponkotha.com/%e0%a6%95%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%95%e0%a7%8d%e0%a6%b0%e0%a6%ae/"> সাম্প্রতিক কার্যক্রম </a>
                                  <a class="dropdown-item" href="https://aponkotha.com/%e0%a6%86%e0%a6%97%e0%a6%be%e0%a6%ae%e0%a7%80-%e0%a6%95%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%95%e0%a7%8d%e0%a6%b0%e0%a6%ae/">আগামী কার্যক্রম</a>
                                  
                             
                        				<!--<//?php wp_nav_menu(array('theme_location'=>'primary-menu','menu_class'=>'my-nav '))?>-->
                        	    </div>
                        	</li>
                        	<li class="nav-item">
                             <a class="nav-item nav-link" href="https://aponkotha.com/%e0%a6%97%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%b2%e0%a6%be%e0%a6%b0%e0%a6%bf/" rel="dofollow">গ্যালারি</a>
                            </li>
                             <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 মিডিয়া
                                </a>
                                 
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="https://aponkotha.com/%e0%a6%ae%e0%a7%81%e0%a6%a6%e0%a7%8d%e0%a6%b0%e0%a6%bf%e0%a6%a4-%e0%a6%ae%e0%a6%bf%e0%a6%a1%e0%a6%bf%e0%a6%af%e0%a6%bc%e0%a6%be/">মুদ্রিত মিডিয়া</a>
                                  <a class="dropdown-item" href="https://aponkotha.com/%e0%a6%87%e0%a6%b2%e0%a7%87%e0%a6%95%e0%a6%9f%e0%a7%8d%e0%a6%b0%e0%a6%a8%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%b8-%e0%a6%ae%e0%a6%bf%e0%a6%a1%e0%a6%bf%e0%a6%af%e0%a6%bc%e0%a6%be/">ইলেকট্রনিক্স মিডিয়া                               </a>
                                  
                             
                        				<!--<//?php wp_nav_menu(array('theme_location'=>'primary-menu','menu_class'=>'my-nav '))?>-->
                        	    </div>
                        	</li>
                            <li class="nav-item dropdown ">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">যোগাযোগ</a>
                 
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                      <a class="dropdown-item" href="https://aponkotha.com/%e0%a6%af%e0%a7%8b%e0%a6%97%e0%a6%be%e0%a6%af%e0%a7%8b%e0%a6%97/">আপনি আমাদের সাথে যোগাযোগ করতে চান</a>
                                      <a class="dropdown-item" href="https://aponkotha.com/%e0%a6%86%e0%a6%ae%e0%a6%be%e0%a6%a6%e0%a7%87%e0%a6%b0-%e0%a6%a0%e0%a6%bf%e0%a6%95%e0%a6%be%e0%a6%a8%e0%a6%be/">আমাদের ঠিকানা      </a>
                                      
                            			  <a class="dropdown-item" href="https://aponkotha.com/wp-admin/admin-ajax.php?action=frm_forms_preview&form=boi-sangrhasala"target="_blank">বই সংগ্রহশালা থেকে তথ্য পেতে-আমাদের সাথে যোগাযোগ করতে চান</a>

                            	    </div>
                 
                            </li>
                            <li class="nav-item ">
                             <a class="nav-item nav-link" href="https://aponkotha.com/%e0%a6%a6%e0%a6%be%e0%a6%a8-%e0%a6%95%e0%a6%b0%e0%a7%81%e0%a6%a8/" rel="dofollow">দান করুন</a>
                            </li>
                            <!--<?php wp_nav_menu(array('theme_location'=>'primary-menu','menu_class'=>'nav-item nav-link '))?>-->
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 col-lg-4">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                            যোগাযোগ
                            </h3><br>
                            
                            <div class="contacts">
                                <p><i class="fa fa-home"></i>চতুর্থ তল, বইমহল
                                    বক্সা ফরেস্ট রোড
                                    আলিপুরদুয়ার, পশ্চিমবঙ্গ 
                                    ভারত , ৭৩৬১২২
                                </p>
                                <p> <i class="fa fa-phone"></i> 9832563014 <br>
                                <p> <i class="fa fa-envelope"></i>aponkoth93@gmail.com<br>
                                <i class="fa fa-globe"></i> <a rel="canonical" hreflang="bn"href="https://aponkotha.com/aaponkotha"style="text-decoration:none;">aponkotha.com</a>
                                </p>
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3570.5147698930887!2d89.52892360000001!3d26.5035639!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e257a603372029%3A0xe531df1465fc872b!2zQm9pbWFoYWwg4Kas4KaH4Kau4Ka54Kay!5e0!3m2!1sen!2sin!4v1716448105997!5m2!1sen!2sin" width="300" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                        
                    </div>
                    
                    
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text">
            <div class="container">
                <div class="row">
                    <div class="bordered_1px "></div>
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                        <p>
                            <a href="<?php echo get_template_directory_uri();?>/terms.pdf" download > Download  Terms & Condition</a>
                            Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script> All rights reserved | This
                            template is made with <i class="ti-heart" aria-hidden="true"></i> by <a
                                href="#" target="_blank">e-Web solutions</a>
                            
                        </p>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
   