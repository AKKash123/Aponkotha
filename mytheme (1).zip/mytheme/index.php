 <meta name="keywords" content="aponkotha-alipurduar,aponkotha,tribes, tribal literature, aponkothango, aponkotha,Alipurduar, Alipurduar-ngo,ngo full form,ngo,ngo near me,ngo in india,ngo website,Aponkotha,aponkotha,aponkotha-ngo,aponkotha ngo,আপন কথা: অবনীন্দ্রনাথ ঠাকুর,Apon Katha - Abanindranath Tagore,Apon Kotha,আপনকথা,ngo in Alipurduar,Alipurduar ngo,Child Rights and You (CRY)">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">


<body>
<div class="first-nav container-fluid"style="margin-left: 111px;
    margin-right: 109px;">
    
    <!--<h3 class="text-primary"style="margin-left:480px;margin-top:25px;">আলকবর্তিকা</h3>-->
    <div class="row">
        <div class="col-sm-12 col-md-6">
            <img class="img-nav" src="<?php echo get_template_directory_uri();?>/images/logo.jpeg" alt="">
            <img class="img-nav1" id="logomain"style="margin-left: 178px; margin-top: -49px;" src="<?php echo get_template_directory_uri();?>/images/aponfont.jpg" alt=""><br>
            
            <small><b><p class="list-item" id="reg1" style="margin-left: 184px;margin-right: 109px;" >রেজিস্ট্রেশন নংঃ S0034893 of 2022-20</p></b></small>
           
            <!--<span class="nav-heading">আপনকথা</span>-->
        </div>
        <div class="col-sm-12 col-md-6 alokktext">
            <h3 class="nav-text text-primary aloktext"style="display:inline;margin-right:-268px;">আ লো ক ব র্তি কা</h3>
        </div>
        
    </div>
      
</div><br>
<div class="container navbar-container container-fluid"style="margin-left: 111px;
    margin-right: 109px;">
				<div class="top-social"style="margin-left: 111px;
    margin-right: 109px;">
					<ul id="top-social-menu">
                    <li class="list-item" id="moto1"style="font-family:sans-serif;"><b>ডুয়ার্সের নৃতত্ত্ব-ভাষা বৈচিত্র্য -সাহিত্য-ইতিহাস-সংস্কৃতি চর্চা, সংরক্ষণ ও বিকাশ</b></li>
                    <br>
                    <li class="list-item" id="moto2"style="font-family:sans-serif;"><b>ডুয়ার্সের পিছিয়ে পরা আদিবাসী অধ্যুষিত অঞ্চলে বই-শিক্ষার আলো ছড়িয়ে দেওয়া।</b></li>
                   
					</ul>
				</div>
			</div>

    <?php get_header();?>

<br>

    <div class="container">
        <div class="row">
            <div class="col-sm">
                <div class="jumbotron-fluid">
                         <!--boi gram-->
                          <a href="https://aponkotha.com/%e0%a6%ac%e0%a6%87%e0%a6%97%e0%a7%8d%e0%a6%b0%e0%a6%be%e0%a6%ae/"target="_blank" aria-expanded="false" aria-controls="multiCollapseExample9 multiCollapseExample10"><p class="text-center">বই গ্রাম</p></a>
                         <img src="<?php echo get_template_directory_uri(); ?>/images/Boigram/boigram2.jpg" alt="boigram" class="img-thumbnail">
                            
                             
                     </div>
                <div class="row">
                     
                    <div class="col-6 col-sm-6">
                         
                        <?php
                                $wppost = array(
                                    'post_type' =>'আলোকবর্তিকা',
                                    'post_status' => 'publish'
                                );
                                //print_r($wppost);
                            $postquery = new wp_Query($wppost);
                            while($postquery->have_posts())
                                    {
                                        $postquery->the_post();
                                    }
                            ?>
                             
                        <a href="https://aponkotha.com/2024/06/06/%e0%a6%86%e0%a6%b2%e0%a7%8b%e0%a6%95%e0%a6%ac%e0%a6%b0%e0%a7%8d%e0%a6%a4%e0%a6%bf%e0%a6%95%e0%a6%be/"target="_blank" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">আলোকবর্তিকা</a>
                        <img src="<?php echo get_template_directory_uri();?>/images/homeimages/alokbartika-ptrika.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                        <?php
                                $wppost1 = array(
                                    'post_type' =>'আপনকথা-সংগ্রহ-শালা',
                                    'post_status' => 'publish'
                                );
                                //print_r($wppost);
                            $postquery1 = new wp_Query($wppost1);
                            while($postquery1->have_posts())
                                    {
                                        $postquery1->the_post();
                                    }
                            ?>
                    <a href="https://aponkotha.com/2024/06/05/%e0%a6%86%e0%a6%a6%e0%a6%bf%e0%a6%ac%e0%a6%be%e0%a6%b8%e0%a7%80-%e0%a6%b8%e0%a6%82%e0%a6%97%e0%a7%8d%e0%a6%b0%e0%a6%b9%e0%a6%b6%e0%a6%be%e0%a6%b2%e0%a6%be/" target="_blank"   aria-expanded="false" aria-controls="multiCollapseExample11 multiCollapseExample12">আদিবাসী সংগ্রহশালা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/sanghrasala.jpg" alt="alokbartika" class="img-thumbnail">
                    
                    </div>

                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-6">
                         <a href="https://aponkotha.com/2024/06/04/%e0%a6%ac%e0%a6%87-%e0%a6%aa%e0%a6%a4%e0%a7%8d%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%be-%e0%a6%b8%e0%a6%82%e0%a6%97%e0%a7%8d%e0%a6%b0%e0%a6%b9%e0%a6%b6%e0%a6%be%e0%a6%b2%e0%a6%be/"target="_blank" aria-expanded="false" aria-controls="multiCollapseExample9 multiCollapseExample10">বই-পত্রিকা সংগ্রহশালা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/boibhandar.jpg" alt="alokbartika" class="img-thumbnail">
                        
                    </div>
                    <div class="col-6 col-sm-6">
                        <a href="https://aponkotha.com/%e0%a6%ac%e0%a6%87%e0%a6%ae%e0%a6%b9%e0%a6%b2/" target="_blank" aria-expanded="false" aria-controls="multiCollapseExample15 multiCollapseExample16">বইমহল</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/boimahal.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="w-100"></div><br>
                    <!--aikhana -dhukba karmasuchi-->
                    <div class="row">
                         <!--<div class="card card-body "style="margin-left: 38px; margin-right: 16px;">-->
                            <!--<img src="<?php echo get_template_directory_uri(); ?>/images/apbaner.jpg" alt="alokbartika" class="img-thumbnail"> -->
                        <!--<h4 class="text-primary ">সাম্প্রতিক কার্যক্রম</h4>-->
                        <!--<div class="col-6 col-sm-4">-->
                        <!--        <//?php-->
                        <!--            $wppost = array(-->
                        <!--                'post_type' =>'upcoming_events',-->
                        <!--               'post_status' => 'publish'-->
                        <!--            );-->
                                    <!--print_r($wppost);-->
                        <!--        $postquery = new wp_Query($wppost);-->
                        <!--        ?>-->
                        <!--        <div class="card-header  cardhead2">&nbsp;কার্যক্রম সমগ্র &nbsp;-->
                        <!--        <button class="btn btn-success"onclick="Loadmore1()" id="myBtn1">আরো দেখুন</button>-->
                        <!--        </div>-->
                        <!--      <//?php-->
                        <!--              while($postquery->have_posts())-->
                        <!--            {-->
                        <!--                  $postquery->the_post();-->
                        <!--                   $imagepath  = wp_get_attachment_image_src(get_post_thumbnail_id(),'small');-->
                                        
                        <!--        ?>-->
                        <!--         <div class="card cardbody1 cardbody2" style="width: 18rem;">-->
                        <!--        <span id="more1"></span>-->
                        <!--        <ul class="list-group list-group-flush">-->
                                
                        <!--            <li class="list-group-item bg-light" id="dots1">-->
                        <!--             <//?php the_title();?> ~ <//?php echo get_the_date();?> <a href="<//?php the_permalink(); ?>"><input type="button" class="btn btn-success seemore" value="আরও জানুন"></a> <hr>-->
                        <!--            </li>-->
    
                        <!--        </div>-->
                        <!--        <//?php } ?>-->
                        <!--</div>-->
                      
                        <!--</div>-->
                    <!--akhana sas hoba div-->
                    <div class="card card-body "style="margin-left: 38px; margin-right: 16px;">
                         <img src="<?php echo get_template_directory_uri(); ?>/images/frame.png" alt="aponkotha" class="img-thumbnail">
                         <p class="text-info">আপনার সৃজনশীলতা আমাদের সাথে শেয়ার করতে অনুগ্রহ করে আপনার ডিভাইসের গুগল লেন্স ব্যবহার করে এই কিউআর কোডটি স্ক্যান করুন</p>
                    </div>
                     <!--<div class="col-8 col-sm-12 mx-auto  mytext card card-body"style="margin-right: 16px;">-->
                     <!--    <p class="text-info">আপনার সৃজনশীলতা আমাদের সাথে শেয়ার করতে অনুগ্রহ করে আপনার ডিভাইসের গুগল লেন্স ব্যবহার করে এই কিউআর কোডটি স্ক্যান করুন</p>-->
                     <!--</div>-->
                    <!--akhana sas hoba form ardiv-->
                </div>
                <br>
                
                </div>
            </div>
            <!--Banner-->
            <div class="col-sm">
            <!--<img src="<?php echo get_template_directory_uri();?>/images/banner.png" alt="aponkotha" class="img-fluid"><br>-->
            <!--carousel-->
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                      <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                      </ol>
                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img src="<?php echo get_template_directory_uri();?>/images/c1.jpg" class="d-block w-100 h-23" alt="aponkotha">
                        </div>
                        <div class="carousel-item">
                          <img src="<?php echo get_template_directory_uri();?>/images/c2.jpg" class="d-block w-100 h-23" alt="aponkotha">
                        </div>
                        <div class="carousel-item">
                          <img src="<?php echo get_template_directory_uri();?>/images/c3.jpg" class="d-block w-100 h-23" alt="aponkotha">
                        </div>
                        <div class="carousel-item">
                          <img src="<?php echo get_template_directory_uri();?>/images/c4.jpg" class="d-block w-100 h-23" alt="aponkotha">
                        </div>
                      </div>
                      
                    </div>
            <!--carousel-->
                <br><div class="row">
                    <br><div class="col-8 col-sm-12 mx-auto card card-head  text-warning" style="margin-left: 77px;margin-top: 17.5px;">
                        পরিচিতি
                        <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap11.jpeg" alt="aponkotha" class="img-thumbnail">
                        
                    </div>
                    <div class="col-8 col-sm-12 mx-auto  mytext card card-body"style="margin-left: 77px;">   
                  <p class="text-dark"><b>আপনকথা</b>আপনকথা একটি অলাভজনক সংস্থা। 
   ডুয়ার্স বহুভাষা ও নৃতত্ত্বের জাদুঘর। তথ্য অনুসারে ১৫১ টি মাতৃভাষার সন্ধান পাওয়া যায়।</p>
<a href=".multi20-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample19">বিস্তারিত</a>
<p class="collapse multi20-collapse" id="multiCollapseExample19"> ভৌগোলিক ঐতিহাসিক আর্থসামাজিক নানাবিধ কারণ সেইসঙ্গে বিশ্বায়নের প্রভাবে ডুয়ার্সের চিরায়ত বৈচিত্র্যে ঘনিয়ে এসেছে গভীর সংকট। এরপরেও বিভিন্ন জনগোষ্ঠীর কিছু কিছু মানুষ নিজস্ব ঐতিহ্য- সংস্কৃতি ভাষা বাঁচিয়ে রাখার প্রাণপণ চেষ্টা করে চলছে। ব্যক্তিগতভাবে বা বিক্ষিপ্তভাবে বিভিন্ন প্রতিষ্ঠান সেই চেষ্টাকে পাশে থেকে এগিয়ে নিয়ে যেতে সহায়তা করছে। এরপরেও ডুয়ার্সের বৈচিত্র্যময় ভাষা-সাহিত্য, স্থানীয় ইতিহাস, সংস্কৃতি সংরক্ষণ করার পাশাপাশি তা চর্চা ও অনুশীলনের মধ্য দিয়ে ভবিষ্যৎ প্রজন্ম ও গবেষকদের কাছে পৌঁছে দেওয়ার চেষ্টার জন্য তৈরি হয়েছে 'আপনকথা' কেন্দ্র। বিগত তিন বছর থেকে এবিষয়ে 'আপনকথা' কাজ করে চলছে। 
                     এছাড়াও পিছিয়ে পড়া এলাকায় শিশু-কিশোর সহ সকলকে বইমুখো করার চেষ্টা করে যাচ্ছে। কারণ বই পারে  মানুষকে সচেতন করতে, সকল প্রকার বঞ্চনা দূর করে নিজের অধিকার বুঝে নিতে সেইসঙ্গে উন্নত জীবনে পৌঁছে দিতে। বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p>

                    </div>
                    
                </div><br>
                <div class="w-100"></div>
                    <div class="row">
                    <!--<div class="card card-body cardstyle ">-->
                    <!--    <h4 class="text-primary mywork">আসন্ন কর্মসূচি</h4><br><br>-->
                    <!--    <div class="col-6 ">-->
                    <!--            <//?php-->
                    <!--                $wppost = array(-->
                    <!--                    'post_type' =>'aponkothapost',-->
                    <!--                    'post_status' => 'publish'-->
                    <!--               // );-->
                                    <!--print_r($wppost);-->
                    <!--           // $postquery = new wp_Query($wppost);-->
                    <!--            ?>-->
                    <!--            <div class="card-header cardhead">&nbsp;&nbsp;কর্মসূচি সমগ্র &nbsp; &nbsp;-->
                    <!--            <button class="btn btn-success"onclick="Loadmore()" id="myBtn">আরো দেখুন</button>-->
                    <!--            </div>-->
                    <!--            <//?php-->
                    <!--                    while($postquery->have_posts())-->
                    <!--                    {-->
                    <!--                        $postquery->the_post();-->
                    <!--                        $imagepath  = wp_get_attachment_image_src(get_post_thumbnail_id(),'small');-->
                                        
                    <!--            ?>-->
                    <!--             <div class="mycard" style="width: 18rem;">-->
                    <!--            <span id="more"></span>-->
                    <!--            <ul class="list-group list-group-flush">-->
                                
                    <!--                <li class="list-group-item bg-light" id="dots">-->
                    <!--                 <//?php the_title();?> ~ <//?php echo get_the_date();?> <a href="<//?php the_permalink(); ?>"><input type="button" class="btn btn-success seemore" value="আরও জানুন"></a> <hr>-->
                    <!--                </li>-->
    
                    <!--            </div>-->
                    <!--            <//?php } ?>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--Boi gram-->
                    <!--    <div class="col-6 col-sm-6 " style="margin-left: 44px;">-->
                    <!--        <img src="<?php echo get_template_directory_uri(); ?>/images/Boigram/boigram.jpg" alt="alokbartika" class="img-thumbnail">-->
                    <!--         <a href="https://aponkotha.com/%e0%a6%ac%e0%a6%87%e0%a6%97%e0%a7%8d%e0%a6%b0%e0%a6%be%e0%a6%ae/"target="_blank" aria-expanded="false" aria-controls="multiCollapseExample9 multiCollapseExample10">বই গ্রাম</a>-->
                            
                    <!--    </div>-->
                    <!--Boi gram-->
                </div>
                <br>
            </div>
            
            <!--Banner-->
            <div class="col-sm">
                <div class="row">
                    <!-- ai khana dhukba-->
                    <div class="w-100"></div>
                    <div class="col-6 col-sm-6">
                        <a href="https://aponkotha.com/%e0%a6%aa%e0%a6%a4%e0%a7%8d%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%be-%e0%a6%a4%e0%a7%87%e0%a6%aa%e0%a6%be%e0%a6%a8%e0%a7%8d%e0%a6%a4%e0%a6%b0%e0%a7%87%e0%a6%b0-%e0%a6%ae%e0%a6%be%e0%a6%a0/" target="_blank"  aria-expanded="false" aria-controls="multiCollapseExample7 multiCollapseExample8">পত্রিকা তেপান্তরের মাঠ</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/tepantorarmath.jpg" alt="alokbartika" class="img-thumbnail">
                        
                   
                    </div>
                    <div class="col-6 col-sm-6">
                        <a href="https://aponkotha.com/%e0%a6%aa%e0%a6%a4%e0%a7%8d%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%be-%e0%a6%8f%e0%a6%ac%e0%a6%82-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%ac%e0%a6%be%e0%a6%b9%e0%a6%ae%e0%a6%be%e0%a6%a8/" target="_blank"  aria-expanded="false" aria-controls="multiCollapseExample3 multiCollapseExample4">পত্রিকা এবং প্রবাহমান</a>
                    <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/probahoman -patrika.jpg" alt="alokbartika" class="img-thumbnail">
                    
                    
                    </div>
                    <div class="w-100"></div>
                    <div class="col-6 col-sm-6">
                        <a href="https://aponkotha.com/%e0%a6%aa%e0%a6%a4%e0%a7%8d%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%be-%e0%a6%86%e0%a6%aa%e0%a6%a8%e0%a6%95%e0%a6%a5%e0%a6%be/" target="_blank"  aria-expanded="false" aria-controls="multiCollapseExample5 multiCollapseExample6">পত্রিকা আপনকথা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/aponkotha-patrika.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                          <a href="https://aponkotha.com/%e0%a6%86%e0%a6%aa%e0%a6%a8%e0%a6%95%e0%a6%a5%e0%a6%be-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%95%e0%a6%be%e0%a6%b6%e0%a6%a8%e0%a6%be/" target="_blank"  aria-expanded="false" aria-controls="multiCollapseExample13 multiCollapseExample14">আপনকথা প্রকাশনা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/aponkotha-publication.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    


                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <br><div class="col-8 col-sm-12 mx-auto mytext card card-body">
                    <b>প্রতিষ্ঠাতা</b>
                    <p class="text-primary"><b>আপনকথা</b></p>
                    <img src="<?php echo get_template_directory_uri();?>/images/pr1.jpg" alt="aponkotha" class="img-thumbnail">
                        <p class="text-primary">ড. পার্থ সাহা</p><br>
                        <!--<a href=".multi20-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample24">বিস্তারিত</a>-->
                        <p class=" text-dark" id="#">জন্ম ৫ জুলাই ১৯৮৭ সাল, তৎকালীন জলপাইগুড়ি জেলায় (বর্তমানে আলিপুরদুয়ার জেলা)। অরণ্য-নদনদী লালিত প্রান্তিক আলিপুরদুয়ার শহরে বেড়ে ওঠা। 
</p><a href=".multi21-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample20">বিস্তারিত</a>
<p class="collapse multi21-collapse"id="multiCollapseExample20">আলিপুরদুয়ার মহাবিদ্যালয় থেকে বাংলায় স্নাতক এবং উত্তরবঙ্গ বিশ্ববিদ্যালয় থেকে স্নাতকোত্তর পড়াশোনা। রায়গঞ্জ বিশ্ববিদ্যালয় থেকে দিব্যেন্দু পালিতের ছোটগল্প নিয়ে পিএইচ.ডি. ডিগ্রী লাভ। 
 পেশায় শিক্ষক, নেশায় 'আলিপুরদুয়ার মানবিক মুখ' নামক সামাজিক সংগঠনের বিশ্বস্ত সৈনিক। পিছিয়ে থাকা আদিবাসী শিশু-কিশোরদের শিক্ষা, ডুয়ার্সের বিভিন্ন ভাষা-সাহিত্য-স্থানীয় ইতিহাস সংরক্ষণ, চর্চা ও বিকাশের জন্য সৃষ্টি করেছেন 'আপনকথা' । বর্তমান সামাজিক অবক্ষয় ও নৈরাশ্যের যুগে দাঁড়িয়ে বিশ্বাস রাখেন মানবিকতায়, স্বপ্ন দেখেন সমাজের গাঢ় অন্ধকার ছাপিয়ে ভোরের আলো ফোটার।</p>

                    </div>
                    
                </div>
            
        </div>
        
    </div>
<br><br>
    <div class="row voulntier container-fluid mt-2">
            <div class="col order-first">
            <img src="<?php echo get_template_directory_uri();?>/images/dipak-kr.jpg" alt="aponkotha" class="img-thumbnail">
            <br>
            <p>ড. দীপক কুমার রায়</p>
            <p>প্রধান উপদেষ্টা -উপাচার্য, রায়গঞ্জ বিশ্ববিদ্যালয় </p>
            </div>
            <div class="col order-second">
                <img src="<?php echo get_template_directory_uri();?>/images/promoth-nath.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <a href=".multi19-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample18" style="text-decoration:none;color:black;">শ্রী প্রমোদ নাথ</a>   
                <p>সভাপতি -বঙ্গরত্ন, লোকসংস্কৃতি গবেষক</p>
                        <div class="collapse multi19-collapse" id="multiCollapseExample18">
                            <div class="card card-body">
                            <p class="mytext text-info">শ্রী প্রমোদ নাথ: লোকচর্চার পথিক ***********  প্রমোদ নাথ জন্ম ২২ ফেব্রুয়ারি, ১৯৪৬ সালে বর্তমান বাংলাদেশের ময়মনসিং জেলার মুক্তাগাছায়। প্রতিষ্ঠাতা সম্পাদক ডুয়ার্স লোকসংস্কৃতি আকাদেমি। ক্ষেত্র সমীক্ষা ও অনুসন্ধানের মধ্য দিয়ে উত্তরের লোকসংস্কৃতি ও আদিবাসী সংস্কৃতি চর্চার সঙ্গে যুক্ত এবং এ বিষয়ে প্রকাশিত গ্রন্থের সংখ্যা চুয়ান্নটি(৫৪)। সম্পাদনা করেন লোকসংস্কৃতি বিষয়ক পত্রিকা 'লোকশ্বর'। ২০১১ সালে লিটল ম্যাগাজিন মেলায় বাংলা আকাদেমি থেকে পেয়েছেন এই পত্রিকার জন্য পুরস্কার ও সংবর্ধনা। প্রতিষ্ঠা করেছেন লোকসংস্কৃতি চর্চা কেন্দ্র- 'লৌকিক'। 'আপনকথা' গবেষণা কেন্দ্রে বর্তমান সভাপতি। আদিবাসী সংস্কৃতিচর্চার জীবনশিল্পী সংস্কৃতি কেন্দ্র সামালী, জোকা, কলকাতা থেকে ২০০৭, রবীন্দ্র ভারতী বিশ্ববিদ্যালয়ের'ফ্যাকাল্টি-অফ-ভিসুয়াল-আর্টস' বিভাগ থেকে ২০১৫ সালে পশ্চিমবঙ্গ সরকারের আদিবাসী উন্নয়ন দপ্তর আয়োজিত 'চা ও আদিবাসী উৎসব' থেকে ২০১৭ সালে এবং সম্প্রীতি আকাদেমি, কলকাতা থেকে পেয়েছেন বিশেষ পুরস্কার ও সংবর্ধনা। সম্প্রতি (২০১৯) ঢাকা বাংলাদেশ রাইটার্স ইন্টারন্যাশনাল থেকে সাহিত্যচর্চার জন্য এবং 'বাংলাদেশ-নেপাল মৈত্রী উৎসব' থেকে পেয়েছেন। বিশেষ সম্মান ও পুরস্কার। সংবর্ধিত হয়েছেন বাংলাদেশ লেখক পরিষদ থেকেও। পশ্চিমবঙ্গ সরকারের 'বঙ্গরত্ন' সম্মানে সম্মানিত হয়েছেন ২০২১ সালে। বিষ্ণুপুর, বাঁকুড়া থেকে পেয়েছেন 'টেরাকোটা' সম্মান, ২০২২ সালে। এ ছাড়াও পেয়েছেন বহু সম্মান ও পুরস্কার। অংশগ্রহণ করেছেন অনেক জাতীয় ও আন্তর্জাতিক আলোচনা সভায়। বর্তমানে অবসরপ্রাপ্ত গ্রন্থাগারকর্মী।</p><br>
                            <p>প্রমোদ নাথের প্রকাশিত গ্রন্থের তালিকা:-</p><br>

                            <p class="mytext text-dark">
                                ০১। ডুয়ার্সের জনজাতি- ২০০২

                                ০২। ডুয়ার্সের আদিবাসী সাহিত্যচর্চা- ২০০৫

                                 ০৩। প্রান্তীয় উত্তরবঙ্গের লোককবি-২০০৫

                                    ০৪। প্রান্তীয় উত্তরবঙ্গের জনজাতি (১ম সংস্করণ)-২০০৫

                                    ০৫। মেঘ মেয়ে (কাব্যগ্রন্থ)-২০০৫

                                    ০৬। মেচ সংস্কৃতির আঙিনায়- ২০০৬

                                    ০৭। উত্তরবঙ্গের আদিবাসী জনজীবনে বিয়ের গান- ২০০৭

                                    ০৮। ডুয়ার্সে নেপালি সাহিত্যচর্চা- ২০০৮

                                    ০৯। মেচ সমাজ ও সংস্কৃতি- ২০০৮

                                    ১০। উত্তরবঙ্গের আদিবাসী জনজীবনে পূজাপার্বণ- ২০০৮

                                    ১১। উত্তরবঙ্গের লোকজীবনে প্রচলিত ধাঁধা-২০০৯

                                    ১২। উত্তরবঙ্গ দর্পণ, ১ম খণ্ড (সম্পাদিত)- ২০০৯

                                    ১৩। উত্তরবঙ্গ দর্পণ, ২য় খণ্ড (সম্পাদিত)- ২০১০

                                    ১৪। লোকায়ত আঙিনায় উত্তরবঙ্গ (সম্পাদিত) - ২০১০

                                    ১৫। তামাঙ- ২০১১

                                    ১৬। উত্তরবঙ্গের আদিবাসী পরিচয়- ২০১১

                                    ১৭। উত্তরবঙ্গের আঞ্চলিক শব্দকোষ (সম্পাদিত)- ২০১১

                                    ১৮। উত্তরবঙ্গের আদিবাসী উৎসব-২০১২

                                    ১৯। উত্তরবঙ্গের আদিবাসী মেচ সমাজ ও সংস্কৃতি- ২০১২

                                    ২০। মগর সমাজ ও সংস্কৃতি- ২০১৩

                                    ২১। উত্তরের রবীন্দ্রনাথ (সম্পাদিত) ২০১৩ ২২। উত্তরের আদিবাসী লোককথা ২০১৪

                                    ২৩। উত্তরের লোকজীবনে লোকঔষধী- ২০১৪

                                    ২৪। উত্তরবঙ্গের ভাষা সমীক্ষা ২০১৫

                                    ২৫। প্রান্তীয় উত্তরবঙ্গের জনজাতি ২০১৫ (২য় সংস্করণ)

                                    ২৬। উত্তরবঙ্গের লোকজীবনে খাদ্য ও পানীয় ২০১৫

                                    ২৭। উত্তরের আদিম আদিবাসী টোটো সম্প্রদায়ের লোকপ্রযুক্তি - ২০১৬

                                    ২৮। উত্তরের আদিবাসী শিল্প-সংস্কৃতির নানা দিগন্ত ২০১৬

                                    ২৯। এক আকাশ অনেক মানুষ (জনজাতির কবিতা সংকলন)- ২০১৬

                                    ৩০। একুশ শতকে টোটো সমাজ ও সংস্কৃতি - ২০১৭

                                    ৩১। উত্তরবঙ্গের নেপালি সমাজ ও সংস্কৃতি - ২০১৭

                                    ৩২। জন্ম-মৃত্যু-বিবাহের আলোকে উত্তরবঙ্গের আদিবাসী সমাজ ২০১৭

                                    ৩৩। উত্তরের লোকসংস্কৃতির নানা দিগন্ত (সম্পাদিত) - ২০১৭

                                    ৩৪। শেরপা সমাজ ও সংস্কৃতি- ২০১৮

                                    ৩৫। লিমু সমাজ ও সংস্কৃতি- ২০১৮

                                    ৩৬। উত্তরের আদিবাসী নৃত্যচর্চা - ২০১৮

                                    ৩৭। ইতিকথায় আলিপুরদুয়ার (সম্পাদিক) ২০১৮

                                    ৩৮। অসুর সমাজ ও সংস্কৃতি - ২০১৯

                                    ৩৯। আদিম আদিবাসী টোটো লোককথা ২০১৯

                                    ৪০। মাহালি সমাজ ও সংস্কৃতি - ২০১৯

                                    ৪১। পশ্চিমবঙ্গের আদিম আদিবাসী পরিচয় - ২০১৯

                                    ৪২। মগর সমাজ ও সংস্কৃতি (হিন্দি অনুবাদ) ২০১৯

                                    ৪৩। শেরপা সমাজ ও সংস্কৃতি (হিন্দি অনুবাদ) - ২০১৯

                                    ৪৪। শেরপা সমাজ ও সংস্কৃতি (নেপালি অনুবাদ) - ২০২০

                                    ৪৫। প্রান্তীয় উত্তরবঙ্গের লোকনাটক ২০২১

                                    ৪৬। আদিম আদিবাসী টোটো ২০২১

                                    ৪৭। স্বাধীনতা আন্দোলনে উত্তরবঙ্গের আদিবাসী সমাজ - ২০২১

                                    ৪৮। আদিবাসী চা-শ্রমিকের জন্ম-মৃত্যু ও বিবাহ প্রথা - ২০২১

                                    ৪৯। উত্তরের আদিবাসী মুখোশ-শিল্প - ২০২১

                                    ৫০। আদিবাসী মেচ লোককথা - ২০২২

                                    ৫১। আদিম জনজাতি টোটো সমাজ জীবনে নারী- ২০২৩

                                    ৫২। নীলকান্ত মুখোপাধ্যায় স্মারক গ্রন্থ (সম্পাদিত) - ২০২৩

                                    ৫৩। আপন কথা (আদিবাসী প্রবন্ধ সংকলন) / (সম্পাদিত) - ২০২৪

                                    ৫৪। দুই বাংলার লোককথা, (ভারত-বাংলাদেশ) / (সম্পাদিত) - ২০২৪
                            </p>
                        </div>
                        </div>
            </div>
            <div class="col order-third">
            <img src="<?php echo get_template_directory_uri();?>/images/shila-sarkar.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <a href=".multi22-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample21" style="text-decoration:none;color:black;">শ্রীমতী শীলা সরকার</a>
                    <p class="collapse multi22-collapse"id="multiCollapseExample21">
                        জন্ম ২৫ শে ফেব্রুয়ারি ১৯৮১ সালের আলিপুরদুয়ার জেলার বারোবিশায়। ১৯৯৭ সালে মাধ্যমিক । ১৯৯৯ উচ্চমাধ্যমিক উত্তীর্ণ। ২০২০ 
                        সালে স্নাতক । ২০০৭ সালে বেসরকারি সংস্থায় চাকরি এবং ২০১১ তে বন্ধন মাইক্রো ফাইন্যান্স অফিসে স্বাস্থ্য বিভাগে চাকুরীতে যোগদান 
                        । এরপর ২০১৩ সালে প্রথম জলপাইগুড়ি জেলার জেলা পরিষদের তিন নং আসনে প্রতিদ্বন্দ্বিতা করে জয়লাভ। 
                        ২০১৪ সালের সেপ্টেম্বর থেকে জেলা পরিষদের কর্মদক্ষ । ২০১৮ সালে পুনরায় পঞ্চায়েত নির্বাচনে জেলা পরিষদের সেই আসনেই জয় লাভ করে আলিপুরদুয়ার জেলা পরিষদের সভাধিপতি 
                        নির্বাচিত। সেই সুবাদে জেলার সমস্ত স্তরের মানুষের সঙ্গে সামাজিক কাজ কর্মের মধ্য দিয়ে কবিতা লেখার প্রয়াস। কবিতার মাধ্যমে সমাজের বিভিন্ন স্তরের অনুভূতি গুলি ফুটে উঠেছে
                        । "নিঃশব্দ তরঙ্গ" চতুর্থ কাব্যগ্রন্থ। প্রথম কাব্যগ্রন্থ "আকাশ প্রান্ত" ২০২১ সালের ৬ অক্টোবর প্রকাশিত হয়েছে
                        । দ্বিতীয় কাব্যগ্রন্থ 'শেষ প্রহর' ১লা জুলাই ২০২২ প্রকাশিত হয়েছে। তৃতীয় কাব্য গ্রন্থ 'প্রত্যক্ষণ' ২০২৩ সালের জানুয়ারীতে, চতুর্থ কাব্য 'নিঃশব্দ তরঙ্গ' ২০২৪ সালের
                        প্রকাশিত হয় ৫ মে। এছাড়াও ডুয়ার্স সমাচার, শব্দ বৃষ্টি,লোকমানস, আলিপুরদুয়ার বইমেলা সংখ্যায়, মন্দাক্রান্তা প্রভৃতি পত্রিকায় কবিতা ও উত্তর প্রসঙ্গ পত্রিকায় স্থানিক ইতিহাস ও ঐতিহ্য সম্পর্কিত প্রবন্ধ ছাপা হয়েছে। আলিপুরদুয়ার জেলা থেকে শীলা সরকার ও পার্থ সাহার যৌথ সম্পাদনায় স্থানীয় ইতিহাস চর্চা ভাষা সাহিত্য ও সংস্কৃতি বিষয়ক "...এবং প্রবাহমান" নামক পত্রিকা প্রকাশিত হচ্ছে।</p>
                    <p>সহ সভাপতি -লেখক</p>
            </div>
            
            <div class="col order-fifth">
            <img src="<?php echo get_template_directory_uri();?>/images/partha-saha.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <p>ড. পার্থ সাহা</p>
                <p>সম্পাদক - শিক্ষক</p>
            </div>
            <div class="col order-sixth">
            <img src="<?php echo get_template_directory_uri();?>/images/cashier.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <p>শ্রীমতী মৌসুমী কর </p>
                <p>কোষাধ্যক্ষ - শিক্ষিকা</p>
            </div>
        </div><br>
<?php get_footer();?>
</body>
<script src="<?php echo get_template_directory_uri();?>/js/loadmore.js"></script>

