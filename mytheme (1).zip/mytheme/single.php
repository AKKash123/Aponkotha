<!DOCTYPE html>
<html lang="en">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta name ="desscription" content="Support our NGO's educational mission in Alipurduar - striving to offer equal educational opportunities for all. Explore indigenous literature from India and various tribes like Garo, Khasi, Jayantia, and other North-Eastern tribes."/>
    <link rel="canonical" href="https://aponkotha.com/" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <?php require_once('functions.php');?>
    <body>
        <?php get_header();?>
        <br>
        
        <?php  $imagepath  = wp_get_attachment_image_src(get_post_thumbnail_id(),'large'); ?>
        <div class="container container-fluid">
            <div class="row">
                <div class="col-9">
                    <h3><span><?php the_title();?></span></h3><br>
                    <p class="text-success"><?php echo get_the_date();?></p><br>
                    <h5 class="text-danger"><?php the_author_meta('display_name', 1); ?></h5>
                   
                </div>
                
                <div class="row">
                     <div class="col-md-4 col-sm-8  card card-body" style="background-color: #bfffbd;">
                    <?php
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => -1
                    );
                    $query = new WP_Query( $args );
                    if ( $query->have_posts() ) :
                        while ( $query->have_posts() ) : $query->the_post(); ?>
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><br>
                        <?php endwhile;
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
                <div class="col-md-8 col-sm-8  card card-body alert alert-success">
                     <img alt="aponkotha" class="img-fluid mx-auto d-block"src="<?php echo $imagepath[0]; ?>">
                     <p class="mycontent text-info"><?php the_content();?></p>
                    <?php echo do_shortcode('[social_share_buttons]');?>
                </div>
                </div>
               
                
            </div>
        </div>
        <br>
        <?php get_footer();?>
    </body>
</html>