 <?php
    register_nav_menus(
        array('primary-menu'=>'Top Menu')
    )
?> 
<?php
function custom_social_share_buttons() {
    // Define the URLs for sharing
    $url = get_permalink();
    $title = get_the_title();
    
    // Define the social media buttons HTML
    $buttons = '<div class="custom-social-share-buttons">';
    $buttons .= '<a href="https://api.whatsapp.com/send?text=' . urlencode($title . ' ' . $url) . '" target="_blank"><i class="fab fa-whatsapp"></i></a>';
    $buttons .= ' | <a href="https://www.facebook.com/sharer/sharer.php?u=' . urlencode($url) . '" target="_blank"><i class="fab fa-facebook"></i></a>';
    $buttons .= ' | <a href="https://twitter.com/intent/tweet?text=' . urlencode($title) . '&url=' . urlencode($url) . '" target="_blank"><i class="fab fa-twitter"></i></a>';
    $buttons .= ' | <a href="https://www.instagram.com/?url=' . urlencode($url) . '" target="_blank"><i class="fab fa-instagram"></i></a>';
    $buttons .= '</div>';
    return $buttons;
}
add_shortcode('social_share_buttons', 'custom_social_share_buttons');
?>