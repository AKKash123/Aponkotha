<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

use WPMailSMTP\Vendor\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends \WPMailSMTP\Vendor\Psr\Http\Client\ClientExceptionInterface
{
}
