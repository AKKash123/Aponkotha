<?php

class BoosterModelBWG {}
