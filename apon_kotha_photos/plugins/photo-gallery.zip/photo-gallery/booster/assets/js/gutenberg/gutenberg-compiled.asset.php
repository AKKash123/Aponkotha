<?php return array('dependencies' => array('wp-element'), 'version' => 'daa06008b8e18dd41da8');
