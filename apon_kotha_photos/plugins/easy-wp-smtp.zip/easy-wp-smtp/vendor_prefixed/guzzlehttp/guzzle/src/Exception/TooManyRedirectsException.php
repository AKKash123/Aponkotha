<?php

namespace EasyWPSMTP\Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends \EasyWPSMTP\Vendor\GuzzleHttp\Exception\RequestException
{
}
