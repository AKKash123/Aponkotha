<?php

namespace EasyWPSMTP\Vendor\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \EasyWPSMTP\Vendor\GuzzleHttp\Exception\GuzzleException
{
}
