<?php

namespace EasyWPSMTP\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
