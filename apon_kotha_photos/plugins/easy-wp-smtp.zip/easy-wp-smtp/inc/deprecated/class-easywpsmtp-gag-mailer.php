<?php

class EasyWPSMTP_Gag_Mailer extends stdClass { //phpcs:ignore

	public function Send() {
		return true;
	}
}
