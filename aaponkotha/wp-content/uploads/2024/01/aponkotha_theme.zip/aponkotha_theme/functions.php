<?php
//Includes all the functionality shortcodes

?>