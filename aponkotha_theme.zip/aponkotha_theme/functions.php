<?php
//Includes all the functionality shortcodes




// function get_template() {
// 	/**
// 	 * Filters the name of the active theme.
// 	 *
// 	 * @since 1.5.0
// 	 *
// 	 * @param string $template active theme's directory name.
// 	 */
//     $template = 'aponkotha_theme';
// 	return apply_filters( 'template', $template );
// }
?>


   
  
   
  
   
    
 