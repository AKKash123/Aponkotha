<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	
<body>
<div class="first-nav container-fluid">
    
    <h3 class="text-primary"style="margin-left:480px;margin-top:25px;">আলকবর্তিকা</h3>
    <img class="img-nav" src="<?php echo get_template_directory_uri();?>/images/logo.jpeg" alt="">আপনকথা
    <ul class="nav-ul">
        <li class="nav-text">ডুয়ার্সের বই আন্দোলন গড়ে তোলা</li><br>
        <li class="nav-text">ডুয়ার্সের নৃত্য ভাষা-সাহিত্য ইতিহাস সংস্কৃতি চর্চা ও সংরক্ষণ</li>
    </ul>  
</div><br>
<div class="container navbar-container container-fluid">
				<div class="top-social">
					<ul id="top-social-menu">
                    <li><i class="fa fa-phone"></i> ৯৮৩২৫৬৩০১৪</li>
					<li><i class="fa fa-home"></i> বইমহল চতুর্থ তলা, আলিপুরদুয়ার আদালত, আলিপুরদুয়ার, পশ্চিমবঙ্গ, ভারত</li>
                    <li><i class="fa fa-book"></i>রেজিস্ট্রেশন নং ঃ S0034893 of 2022-2023</li>
					</ul>
				</div>
			</div>
<br>
<?php get_header();?><br>

    <div class="container">
        <div class="row">
            <div class="col-sm">
                <div class="row">
                    <div class="col-6 col-sm-6">
                        <a href="/alokbartika.php">আলকবর্তিকা</a>
                        <img src="<?php echo get_template_directory_uri();?>/images/Alokbartika/alo6.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href="#">পত্রিকা এবং প্রবাহমান</a>
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Prabahoman/prob6.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>

                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-6"><a href="#">পত্রিকা আপনকথা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Aponkotha/ap3.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href="#">পত্রিকা তেপান্তরের মাঠ</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Tapantorermath/tap4.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="w-100"></div>
                    <div class="col-6 col-sm-6"><a href="#">আপনকথা বই ভান্ডার</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi1.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href="#">আপনকথা সংগ্রহ শালা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi2.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="w-100"></div>
                    <div class="col-6 col-sm-6"><a href="#">আপনকথা প্রকাশনা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Aponkotha/ap5.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href="#">বইমহল</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi4.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                </div>
            </div>
            <!--Banner-->
            <div class="col-sm">
            <img src="<?php echo get_template_directory_uri();?>/images/banner.png" alt="aponkotha" class="img-fluid">
                <div class="row">
                    <div class="col-6 col-sm-6">
                        
                        <img src="<?php echo get_template_directory_uri();?>/images/Alokbartika/alo6.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    
                    <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap7.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>

                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-6">
                        <img src="<?php echo get_template_directory_uri();?>/images/Prabahoman/prob1.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    
                        <img src="<?php echo get_template_directory_uri();?>/images/Tapantorermath/tap6.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    
                </div><br>
                <div class="w-100"></div>
                <div class="row">
                    <h4 class="text-primary">আসন্ন কর্মসূচি</h4><br><br>
                    <div class="col-6">
                            <?php
                                $wppost = array(
                                    'post_type' =>'aponkothapost',
                                    'post_status' => 'publish'
                                );
                                //print_r($wppost);
                            $postquery = new wp_Query($wppost);
                            ?>
                            <div class="card-header cardhead">&nbsp;&nbsp;কর্মসূচি সমগ্র</div>
                            <?php
                                    while($postquery->have_posts())
                                    {
                                        $postquery->the_post();
                                        $imagepath  = wp_get_attachment_image_src(get_post_thumbnail_id(),'small');
                                    
                            ?>
                            <div class="mycard" style="width: 18rem;">
                            <ul class="list-group list-group-flush">

                                <li class="list-group-item bg-light">
                                 <?php the_title();?> ~ <?php echo get_the_date();?> <a href="<?php the_permalink(); ?>"><input type="button" class="btn btn-success" value="আরও জানুন"></a> <hr>
                                </li>
                            </div>
                            <?php } ?>
                    </div>
                </div>
                <br>
            </div>
            
            <!--Banner-->
            <div class="col-sm">
                <div class="row">
                    <div class="col-6 col-sm-8">
                        পরিচিতি
                        <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap11.jpeg" alt="aponkotha" class="img-thumbnail">
                        
                    </div>
                    <div class="col-6 col-sm-8">   
                    <p class="text-dark"><b>আপনকথা</b>-একটি অলাভজনক সংস্থা শিক্ষার প্রচার এবং শেখার সুযোগ বৃদ্ধির জন্য নিবেদিত,
                             ডুয়ার্স অঞ্চলের প্রত্যন্ত অঞ্চলে শিক্ষার্থীদের জীবনে ইতিবাচক প্রভাব ফেলতে প্রতিশ্রুতিবদ্ধ। 
                             আমাদের উদ্যোগের লক্ষ্য হল প্রয়োজনীয় সম্পদ, যেমন বই এবং অধ্যয়নের উপকরণ প্রদানের মাধ্যমে শিক্ষাগত ব্যবধান পূরণ করা,
                             যারা মানসম্পন্ন শিক্ষা অর্জনের ক্ষেত্রে চ্যালেঞ্জের সম্মুখীন হয়।</p>
                        <p class="text-info">
                            ডুয়ার্সের বনবস্তি বা আদিবাসী অধ‍্যুষিত এলাকার শিশুরা অধিকাংশই প্রথম প্রজন্মের শিক্ষার্থী। 
                            অনেক সময়েই আর্থসামাজিক কারণবশত তারা বইবিমুখ, শিক্ষাঙ্গন বিমুখ। 
                            সেইসব শিশুদের জন্য :<p class="text-dark">বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p>
                    </div>


                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-8">
                    <b>প্রতিষ্ঠাতা</b>
                        <p class="text-dark"><b>আপনকথা</b></p>
                        <p class="text-dark">এই উদ্যোগের প্রাথমিক উদ্দেশ্য হল ডুয়ার্স অঞ্চলের শিক্ষার্থীদের শেখার জন্য প্রয়োজনীয় সরঞ্জামগুলির সাথে সজ্জিত করে তাদের ক্ষমতায়ন করা। 
                            আমরা তাদের শিক্ষাগত অভিজ্ঞতা বাড়াতে এবং এই সম্প্রদায়গুলির সামগ্রিক উন্নয়নে অবদান রাখার চেষ্টা করি। </p>
                    </div>
                    <div class="col-6 col-sm-8">
                    <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap4.jpeg" alt="aponkotha" class="img-thumbnail">
                    </div>
                </div>
            
        </div>
        
    </div><br>
    <div class="row">
            <div class="col order-last">
            <img src="<?php echo get_template_directory_uri();?>/images/partha_saha.jpeg" alt="aponkotha" class="img-thumbnail"><br>
                <p>ড. পার্থ সাহা</p>
                <p>সম্পাদক</p>
            </div>
            <div class="col order-fourth">
            <img src="<?php echo get_template_directory_uri();?>/images/ajit_sir.jpeg" alt="aponkotha" class="img-thumbnail"><br>
                <p>শ্রী অজিত কুমার নাথ</p>
                <p>সহ সভাপতি</p>
            </div>
            <div class="col order-third">
            <img src="<?php echo get_template_directory_uri();?>/images/shrila_mam.jpeg" alt="aponkotha" class="img-thumbnail"><br>
                <p>শ্রীমতি শিলা সরকার</p>
                <p>সহ সভাপতি</p>
            </div>
            <div class="col order-second">
            <img src="<?php echo get_template_directory_uri();?>/images/savapati.jpeg" alt="aponkotha" class="img-thumbnail"><br>
                <p>শ্রী প্রমথ নাথ</p>
                <p>সভাপতি</p>
            </div>
            <div class="col order-first">
            <img src="<?php echo get_template_directory_uri();?>/images/dipak_kr.jpg" alt="aponkotha" class="img-thumbnail">
            <br>
            <p>ড. দীপক কুমার রায়</p>
            <p>প্রধান উপদেষ্টা</p>
            </div>
        </div><br>
<?php get_footer();?>
</body>

