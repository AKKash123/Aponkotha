<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">


<body>
<div class="first-nav container-fluid">
    
    <!--<h3 class="text-primary"style="margin-left:480px;margin-top:25px;">আলকবর্তিকা</h3>-->
    <div class="row">
        <div class="col-sm-12 col-md-6">
            <img class="img-nav" src="<?php echo get_template_directory_uri();?>/images/logo.jpeg" alt="">
            <span class="nav-heading">আপনকথা</span>

        </div>
        <div class="col-sm-12 col-md-6">
            <h3 class="nav-text text-primary">আলকবর্তিকা</h3>
            <ul class="nav-ul">
                <li class="list-item">ডুয়ার্সের বই আন্দোলন গড়ে তোলা</li><br>
                <li class="list-item">ডুয়ার্সের নৃত্য ভাষা-সাহিত্য ইতিহাস সংস্কৃতি চর্চা ও সংরক্ষণ</li>
            </ul>
        </div>
        
    </div>
      
</div><br>
<div class="container navbar-container container-fluid">
				<div class="top-social">
					<ul id="top-social-menu">
                    <li><i class="fa fa-phone"></i> ৯৮৩২৫৬৩০১৪</li>
					<li><i class="fa fa-home"></i> বইমহল চতুর্থ তলা, আলিপুরদুয়ার আদালত, আলিপুরদুয়ার, পশ্চিমবঙ্গ, ভারত</li>
                    <li><i class="fa fa-book"></i>রেজিস্ট্রেশন নং ঃ S0034893 of 2022-2023</li>
					</ul>
				</div>
			</div>
<br>
<?php get_header();?><br>

    <div class="container">
        <div class="row">
            <div class="col-sm">
                <div class="row">
                    <div class="col-6 col-sm-6">
                        <a href=".multi-collapse"data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">আলকবর্তিকা</a>
                        <img src="<?php echo get_template_directory_uri();?>/images/homeimages/alokbartika-ptrika.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href=".multi1-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample3 multiCollapseExample4">পত্রিকা এবং প্রবাহমান</a>
                    <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/probahoman -patrika.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>

                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-6">
                    <a href=".multi2-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample5 multiCollapseExample6">পত্রিকা আপনকথা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/aponkotha-patrika.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href=".multi3-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample7 multiCollapseExample8">পত্রিকা তেপান্তরের মাঠ</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/tepantorarmath.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="w-100"></div>
                    <div class="col-6 col-sm-6">
                    <a href=".multi4-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample9 multiCollapseExample10">আপনকথা বই ভান্ডার</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/boibhandar.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href=".multi5-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample11 multiCollapseExample12">আপনকথা সংগ্রহ শালা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/sanghrasala.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="w-100"></div>
                    <div class="col-6 col-sm-6">
                    <a href=".multi6-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample13 multiCollapseExample14">আপনকথা প্রকাশনা</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/aponkotha-publication.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    <a href=".multi7-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample15 multiCollapseExample16">বইমহল</a>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/homeimages/boimahal.jpg" alt="alokbartika" class="img-thumbnail">
                    </div>
                </div>
            </div>
            <!--Banner-->
            <div class="col-sm">
            <img src="<?php echo get_template_directory_uri();?>/images/banner.png" alt="aponkotha" class="img-fluid">
                <div class="row">
                    <div class="col-6 col-sm-6">
                        
                        <img src="<?php echo get_template_directory_uri();?>/images/Alokbartika/alo6.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    
                    <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap7.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>

                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-6">
                        <img src="<?php echo get_template_directory_uri();?>/images/Prabahoman/prob1.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    <div class="col-6 col-sm-6">
                    
                        <img src="<?php echo get_template_directory_uri();?>/images/Tapantorermath/tap6.jpeg" alt="alokbartika" class="img-thumbnail">
                    </div>
                    
                </div><br>
                <div class="w-100"></div>
                <div class="row">
                    <h4 class="text-primary mywork">আসন্ন কর্মসূচি</h4><br><br>
                    <div class="col-6">
                            <?php
                                $wppost = array(
                                    'post_type' =>'aponkothapost',
                                    'post_status' => 'publish'
                                );
                                //print_r($wppost);
                            $postquery = new wp_Query($wppost);
                            ?>
                            <div class="card-header cardhead">&nbsp;&nbsp;কর্মসূচি সমগ্র &nbsp; &nbsp;
                            <button class="btn btn-success"onclick="Loadmore()" id="myBtn">আরো দেখুন</button>
                            </div>
                            <?php
                                    while($postquery->have_posts())
                                    {
                                        $postquery->the_post();
                                        $imagepath  = wp_get_attachment_image_src(get_post_thumbnail_id(),'small');
                                    
                            ?>
                             <div class="mycard" style="width: 18rem;">
                            <span id="more"></span>
                            <ul class="list-group list-group-flush">
                            
                                <li class="list-group-item bg-light" id="dots">
                                 <?php the_title();?> ~ <?php echo get_the_date();?> <a href="<?php the_permalink(); ?>"><input type="button" class="btn btn-success seemore" value="আরও জানুন"></a> <hr>
                                </li>

                            </div>
                            <?php } ?>
                    </div>
                </div>
                <br>
            </div>
            
            <!--Banner-->
            <div class="col-sm">
                <div class="row">
                    <div class="col-6 col-sm-8">
                        পরিচিতি
                        <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap11.jpeg" alt="aponkotha" class="img-thumbnail">
                        
                    </div>
                    <div class="col-6 col-sm-8 mytext">   
                    <p class="text-dark"><b>আপনকথা</b>-একটি অলাভজনক সংস্থা শিক্ষার প্রচার এবং শেখার সুযোগ বৃদ্ধির জন্য নিবেদিত,
                             ডুয়ার্স অঞ্চলের প্রত্যন্ত অঞ্চলে শিক্ষার্থীদের জীবনে ইতিবাচক প্রভাব ফেলতে প্রতিশ্রুতিবদ্ধ। 
                             আমাদের উদ্যোগের লক্ষ্য হল প্রয়োজনীয় সম্পদ, যেমন বই এবং অধ্যয়নের উপকরণ প্রদানের মাধ্যমে শিক্ষাগত ব্যবধান পূরণ করা,
                             যারা মানসম্পন্ন শিক্ষা অর্জনের ক্ষেত্রে চ্যালেঞ্জের সম্মুখীন হয়।</p>
                        <p class="text-info">
                            ডুয়ার্সের বনবস্তি বা আদিবাসী অধ‍্যুষিত এলাকার শিশুরা অধিকাংশই প্রথম প্রজন্মের শিক্ষার্থী। 
                            অনেক সময়েই আর্থসামাজিক কারণবশত তারা বইবিমুখ, শিক্ষাঙ্গন বিমুখ। 
                            সেইসব শিশুদের জন্য :<p class="text-dark">বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p>
                    </div>


                    <!-- Force next columns to break to new line -->
                    <div class="w-100"></div>

                    <div class="col-6 col-sm-8 mytext">
                    <b>প্রতিষ্ঠাতা</b>
                        <p class="text-dark"><b>আপনকথা</b></p>
                        <p class="text-dark">এই উদ্যোগের প্রাথমিক উদ্দেশ্য হল ডুয়ার্স অঞ্চলের শিক্ষার্থীদের শেখার জন্য প্রয়োজনীয় সরঞ্জামগুলির সাথে সজ্জিত করে তাদের ক্ষমতায়ন করা। 
                            আমরা তাদের শিক্ষাগত অভিজ্ঞতা বাড়াতে এবং এই সম্প্রদায়গুলির সামগ্রিক উন্নয়নে অবদান রাখার চেষ্টা করি। </p>
                    </div>
                    <div class="col-6 col-sm-8">
                    <img src="<?php echo get_template_directory_uri();?>/images/Aponkotha/ap4.jpeg" alt="aponkotha" class="img-thumbnail">
                    </div>
                </div>
            
        </div>
        
    </div><br>
    <div class="row">
        <div class="col">
            <div class="collapse multi-collapse" id="multiCollapseExample1">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Alokbartika/alo6.jpeg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi-collapse" id="multiCollapseExample2">
                            <div class="card card-body">
                                <p class="text-dark"><b>আলকবর্তিকা</b>- <p class="text-dark">বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p> -প্রত্যন্ত অঞ্চলের কেন্দ্রস্থলে, যেখানে শিক্ষার সংস্থানগুলির অ্যাক্সেস সীমিত,
                                    শিশুদের জন্য একচেটিয়াভাবে তৈরি করা একটি ছোট গ্রন্থাগারের আকারে আশার আলো দেখা দিয়েছে। আলকবর্তিকা হল একটি উদ্যোগ যার লক্ষ্য হল দূরবর্তী এবং সুবিধাবঞ্চিত সম্প্রদায়ের শিশুদের শিক্ষাগত সহায়তা প্রদান করা, 
                                    যাতে প্রত্যেক শিশুর একটি বইয়ের পাতার মাধ্যমে বিশ্ব অন্বেষণ করার সুযোগ থাকে।</p>
                                    <h3 class="text-info">পরিচালনা ও ব্যবস্থাপনা</h3>
                                    <p class="text-dark">
                                        ডুয়ার্সের জেলার পিছিয়ে পড়া গ্রামের
                                        ছেলেমেয়েদের বইমুখী করতে উদ্যোগ
                                        নিল আলিপুরদুয়ারের স্বেচ্ছাসেবী সংস্থা
                                        বইমহল আপনকথা। শনিবার বিভিন্ন বই
                                        নিয়ে টোটোপাড়ায় হাজির হয়েছিলেন
                                        ওই সংগঠনের সদস্যরা। এলাকার পাঁচটি এদিন উপস্থিত ছিলেন
                                        প্রাথমিক বিদ্যালয়ের পড়ুয়াদের ওই আলিপুরদুয়ারের জেলা শাসক আর
                                        সংগঠনের সাধারণ সম্পাদক
                                        পার্থ সাহার কথায়, ‘জেলার পিছিয়ে
                                        পড়া এলাকার শিশুদের বইমুখী করা
                                        আমাদের উদ্দেশ্য। তাই এই কর্মসূচি
                                        করা হয়েছে।'
                                        সঙ্গে আমরা শেলারোহণ শিক্ষা শাবরও
                                        করি। আলিপুরদুয়ারের চা বাগানের
                                        পাশাপাশি বনবস্তির ছেলেমেয়েরাও
                                        সেখানে অংশ নেয়। তাদের কাছ থেকে
                                        ন্যূনতম টাকা নেওয়া হয়। রাজ্যের
                                        বিভিন্ন জায়গা, এমনকি অসম থেকেও
                                        ছাত্রছাত্রীরা আসে। এটা বাতিল হওয়ায়
                                        সবার মন ভেঙে গিয়েছে।' বন দপ্তরের
                                        এদিন আলিপুরদুয়ারের প্রাক্তন বিধায়ক
                                        নির্মল দাস বলেন, “এধরনের ঘটনা
                                        যেন ভবিষ্যতে না ঘটে, সেটাও নিশ্চিত
                                        করতে হবে।'
                                        টোটোপাড়ায় বই বিতরণ
                                        বিমলা, জেলা ভূমি ও ভূমি রাজস্ব
                                        আধিকারিক নৃপেন্দ্র সিং, মাদারিহাটের
                                        বিডিও সুবর খান, বঙ্গরত্ন প্রমোদ নাথ,
                                        পদ্মশ্রী ধনীরাম টোটো প্রমুখ।
                                        জেলা শাসক বলেন, 'এই ধরনের
                                        উদ্যোগ শিশুদের বইমুখী করতে সাহায্য
                                        করবে। বিশেষ করে প্রথম প্রজন্মের
                                        শিক্ষার্থীদের ভীষণ উপকার হবে।'
                                    </p>
                                    <h3 class="text-warning">উদ্দেশ্য:</h3>
                                    <p class="text-dark">এই উদ্যোগের প্রাথমিক উদ্দেশ্য হল ডুয়ার্স অঞ্চলের শিক্ষার্থীদের শেখার জন্য প্রয়োজনীয় সরঞ্জামগুলির সাথে সজ্জিত করে তাদের ক্ষমতায়ন করা। 
                                        আমরা তাদের শিক্ষাগত অভিজ্ঞতা বাড়াতে এবং এই সম্প্রদায়গুলির সামগ্রিক উন্নয়নে অবদান রাখার চেষ্টা করি। </p>
                            </div>
                </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <div class="collapse multi1-collapse" id="multiCollapseExample3">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Prabahoman/prob7.jpg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Prabahoman/prob8.jpg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi1-collapse" id="multiCollapseExample4">
                            <div class="card card-body">
                                <h3><span>প্রবহমান</span></h3>
                                <p class="text-dark"><b>প্রবহমান</b>-স্থানিক চর্চা ব্যতিরেকে কোনও ইতিহাস পূর্ণতা পায় না, ঠিক যেমন করে উপনদীর জল পুষ্ট করে প্রধান নদীকে এবং সেই নদী পাহাড়-পর্বত-অরণ্য-জনপদ ছুঁয়ে মিশে যায় মহাসমুদ্রে। ঠিক তেমন স্থানীয় ইতিহাস-ভাষা-সাহিত্য-সংস্কৃতি চর্চার প্রবাহ পুষ্ট করে এক পূর্ণাঙ্গ ইতিহাসের সন্ধানকে। সেই চেষ্টার মাধ্যম হল '...এবং প্রবহমান ' পত্রিকা।  প্রথম প্রকাশ মহালয়া, ২০২৩। বার্ষিক এই পত্রিকার সম্পাদক শীলা সরকার, ড.পার্থ সাহা। 
                                    নামকরণ করেন ড.পার্থ সাহা, প্রচ্ছদ অরিন্দম বসু, মুদ্রণ সুরজিৎ বণিক(বিয়ন্ড হরাইজন পাবলিকেশন)।</p>
                                    <h3 class="text-info">পরিচালনা ও ব্যবস্থাপনা</h3>
                                <p class="text-info">
                                    প্রথম প্রকাশ মহালয়া, ২০২৩ :<p class="text-dark">মুদ্রণ সুরজিৎ বণিক(বিয়ন্ড হরাইজন পাবলিকেশন)</p>
                                </p>
                                <h3 class="text-warning">উদ্দেশ্য:</h3>
                                <p class="text-dark">
                                    ১) স্থানীয় ইতিহাস, ভূগোল নৃ-তত্ত্ব ,ভাষা,সাহিত্য,সংস্কৃতি-র অনুসন্ধান। 
                                    ২) উক্ত বিষয়ে চর্চা ও সংরক্ষণ।
                                    ৩) মূল ইতিহাসের সাথে যোগসূত্র তৈরি। 
                                    ৪) নতুন প্রজন্ম, গবেষকদের কাছে আকর্ষণীয় করার চেষ্টা। 
                                </p>
                            </div>
                </div>
        </div>
    </div><br>

    <div class="row">
        <div class="col">
            <div class="collapse multi2-collapse" id="multiCollapseExample5">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Aponkotha/ap4.jpeg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Aponkotha/ap7.jpeg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi2-collapse" id="multiCollapseExample6">
                            <div class="card card-body">
                                <h3><span>পত্রিকা আপনকথা</span></h3>
                                <p class="text-dark"><b>পত্রিকা আপনকথা</b>-
                                <h4><b>লক্ষ্য :</b></h4>
                                <p class="text-info">১) জেলার বিভিন্ন বনবস্তী এলাকায় শিশুদের বই বিমুখতা কাটিয়ে বইমুখী করা।</p>
                                <p class="text-info">২) বই যে ব্যক্তি ও সমাজ-জীবনের সমস্যা নিরাময়ের প্রধান অস্ত্র হতে পারে সেই বিষয়ে  মানুষের মধ‍্যে সচেতনতা বৃদ্ধি। </p>
                                <p class="text-info"> ৩) বইকে কেন্দ্র করে কু-সংস্কার দূর করে বিজ্ঞানমনস্কতা ছড়িয়ে দেওয়া। </p>
                            </div>
                </div>
        </div>
    </div><br>

    <div class="row">
        <div class="col">
            <div class="collapse multi3-collapse" id="multiCollapseExample7">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/insidepic/tepantor1.jpg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
           <img src="<?php echo get_template_directory_uri(); ?>/images/insidepic/tepantor2.jpg" class="img-thumbnail">
            </div><br>
             <div class="card card-body">
             <img src="<?php echo get_template_directory_uri(); ?>/images/insidepic/tepantor3.jpg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi3-collapse" id="multiCollapseExample8">
                            <div class="card card-body">
                                <h3><span>পত্রিকা তেপান্তরের মাঠ</span></h3>
                                <h3 class="text-info">পরিচালনা ও ব্যবস্থাপনা</h3>
                                <p class="text-info">
                                ডুয়ার্সের বনবস্তি বা আদিবাসী অধ‍্যুষিত এলাকার শিশুরা অধিকাংশই প্রথম প্রজন্মের শিক্ষার্থী। 
                                অনেক সময়েই আর্থসামাজিক কারণবশত তারা বইবিমুখ, শিক্ষাঙ্গন বিমুখ। 
                                সেইসব শিশুদের জন্য :<p class="text-dark">বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p>
                            </div>
                </div>
        </div>
    </div><br>

    <div class="row">
        <div class="col">
            <div class="collapse multi4-collapse" id="multiCollapseExample9">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi1.jpeg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi2.jpeg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi4-collapse" id="multiCollapseExample10">
                            <div class="card card-body">
                                <h3><span>আপনকথা বই ভান্ডার</span></h3>
                                <h3 class="text-info">পরিচালনা ও ব্যবস্থাপনা</h3>
                                <p class="text-info">
                                ডুয়ার্সের বনবস্তি বা আদিবাসী অধ‍্যুষিত এলাকার শিশুরা অধিকাংশই প্রথম প্রজন্মের শিক্ষার্থী। 
                                অনেক সময়েই আর্থসামাজিক কারণবশত তারা বইবিমুখ, শিক্ষাঙ্গন বিমুখ। 
                                সেইসব শিশুদের জন্য :<p class="text-dark">বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p>
                            </div>
                </div>
        </div>
    </div><br>

    <div class="row">
        <div class="col">
            <div class="collapse multi5-collapse" id="multiCollapseExample11">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/insidepic/sangra1.jpg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi2.jpeg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi5-collapse" id="multiCollapseExample12">
                            <div class="card card-body">
                                <h3><span>আপনকথা সংগ্রহ শালা</span></h3>
                                <h3 class="text-warning">উদ্দেশ্য:</h3>
                                    <p class="text-dark">এই উদ্যোগের প্রাথমিক উদ্দেশ্য হল ডুয়ার্স অঞ্চলের শিক্ষার্থীদের শেখার জন্য প্রয়োজনীয় সরঞ্জামগুলির সাথে সজ্জিত করে তাদের ক্ষমতায়ন করা। 
                                        আমরা তাদের শিক্ষাগত অভিজ্ঞতা বাড়াতে এবং এই সম্প্রদায়গুলির সামগ্রিক উন্নয়নে অবদান রাখার চেষ্টা করি।</p>
                                <h4><b>লক্ষ্য :</b></h4>
                                <p class="text-info">১) জেলার বিভিন্ন বনবস্তী এলাকায় শিশুদের বই বিমুখতা কাটিয়ে বইমুখী করা।</p>
                                <p class="text-info">২) বই যে ব্যক্তি ও সমাজ-জীবনের সমস্যা নিরাময়ের প্রধান অস্ত্র হতে পারে সেই বিষয়ে  মানুষের মধ‍্যে সচেতনতা বৃদ্ধি। </p>
                                <p class="text-info"> ৩) বইকে কেন্দ্র করে কু-সংস্কার দূর করে বিজ্ঞানমনস্কতা ছড়িয়ে দেওয়া। </p>
                            </div>
                </div>
        </div>
    </div><br>

    <div class="row">
        <div class="col">
            <div class="collapse multi6-collapse" id="multiCollapseExample13">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Aponkotha/ap5.jpeg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Aponkotha/ap9.jpeg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi6-collapse" id="multiCollapseExample14">
                            <div class="card card-body">
                                <h3><span>আপনকথা প্রকাশনা</span></h3>
                                <h3 class="text-warning">উদ্দেশ্য:</h3>
                                    <p class="text-dark">এই উদ্যোগের প্রাথমিক উদ্দেশ্য হল ডুয়ার্স অঞ্চলের শিক্ষার্থীদের শেখার জন্য প্রয়োজনীয় সরঞ্জামগুলির সাথে সজ্জিত করে তাদের ক্ষমতায়ন করা। 
                                        আমরা তাদের শিক্ষাগত অভিজ্ঞতা বাড়াতে এবং এই সম্প্রদায়গুলির সামগ্রিক উন্নয়নে অবদান রাখার চেষ্টা করি।</p>
                                <h4><b>লক্ষ্য :</b></h4>
                                <p class="text-info">১) জেলার বিভিন্ন বনবস্তী এলাকায় শিশুদের বই বিমুখতা কাটিয়ে বইমুখী করা।</p>
                                <p class="text-info">২) বই যে ব্যক্তি ও সমাজ-জীবনের সমস্যা নিরাময়ের প্রধান অস্ত্র হতে পারে সেই বিষয়ে  মানুষের মধ‍্যে সচেতনতা বৃদ্ধি। </p>
                                <p class="text-info"> ৩) বইকে কেন্দ্র করে কু-সংস্কার দূর করে বিজ্ঞানমনস্কতা ছড়িয়ে দেওয়া। </p>
                            </div>
                </div>
        </div>
    </div><br>

    <div class="row">
        <div class="col">
            <div class="collapse multi7-collapse" id="multiCollapseExample15">
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi2.jpeg" class="img-thumbnail">
            </div><br>
            <div class="card card-body">
            <img src="<?php echo get_template_directory_uri(); ?>/images/Boimahal/boi4.jpeg" class="img-thumbnail">
            </div>
            </div>
        </div>
        <div class="col">
            <div class="collapse multi7-collapse" id="multiCollapseExample16">
                            <div class="card card-body">
                                <h3><span>বইমহল</span></h3>
                                <p class="text-info">বইমহল আপনকথা'-এর একটি প্রকল্প 'আলোকবর্তিকা' ছোটোদের ছোট্ট লাইব্রেরি।</p>
                                <h3 class="text-warning">উদ্দেশ্য:</h3>
                                    <p class="text-dark">এই উদ্যোগের প্রাথমিক উদ্দেশ্য হল ডুয়ার্স অঞ্চলের শিক্ষার্থীদের শেখার জন্য প্রয়োজনীয় সরঞ্জামগুলির সাথে সজ্জিত করে তাদের ক্ষমতায়ন করা। 
                                        আমরা তাদের শিক্ষাগত অভিজ্ঞতা বাড়াতে এবং এই সম্প্রদায়গুলির সামগ্রিক উন্নয়নে অবদান রাখার চেষ্টা করি।</p>

                            </div>
                </div>
        </div>
    </div><br>
    <div class="row voulntier">
            <div class="col order-fifth">
            <img src="<?php echo get_template_directory_uri();?>/images/partha-saha.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <p>ড. পার্থ সাহা</p>
                <p>সম্পাদক - শিক্ষক</p>
            </div>
            <div class="col order-fourth">
            <img src="<?php echo get_template_directory_uri();?>/images/ajit-sir.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <p>শ্রী অজিত কুমার নাথ</p>
                <p>সহ সভাপতি</p>
            </div>
            <div class="col order-third">
            <img src="<?php echo get_template_directory_uri();?>/images/shila-sarkar.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <p>শ্রীমতী শীলা সরকার</p>
                <p>সহ সভাপতি -লেখক</p>
            </div>
            <div class="col order-second">
                <img src="<?php echo get_template_directory_uri();?>/images/promoth-nath.jpg" alt="aponkotha" class="img-thumbnail"><br>
                <a href=".multi19-collapse" data-toggle="collapse"  aria-expanded="false" aria-controls="multiCollapseExample18">শ্রী প্রমোদ নাথ</a>   
                <p>সভাপতি -বঙ্গরত্ন, লোকসংস্কৃতি গবেষক</p>
                        <div class="collapse multi19-collapse" id="multiCollapseExample18">
                            <div class="card card-body">
                            <p class="mytext text-info">শ্রী প্রমোদ নাথ: লোকচর্চার পথিক ***********  প্রমোদ নাথ জন্ম ২২ ফেব্রুয়ারি, ১৯৪৬ সালে বর্তমান বাংলাদেশের ময়মনসিং জেলার মুক্তাগাছায়। প্রতিষ্ঠাতা সম্পাদক ডুয়ার্স লোকসংস্কৃতি আকাদেমি। ক্ষেত্র সমীক্ষা ও অনুসন্ধানের মধ্য দিয়ে উত্তরের লোকসংস্কৃতি ও আদিবাসী সংস্কৃতি চর্চার সঙ্গে যুক্ত এবং এ বিষয়ে প্রকাশিত গ্রন্থের সংখ্যা চুয়ান্নটি(৫৪)। সম্পাদনা করেন লোকসংস্কৃতি বিষয়ক পত্রিকা 'লোকশ্বর'। ২০১১ সালে লিটল ম্যাগাজিন মেলায় বাংলা আকাদেমি থেকে পেয়েছেন এই পত্রিকার জন্য পুরস্কার ও সংবর্ধনা। প্রতিষ্ঠা করেছেন লোকসংস্কৃতি চর্চা কেন্দ্র- 'লৌকিক'। 'আপনকথা' গবেষণা কেন্দ্রে বর্তমান সভাপতি। আদিবাসী সংস্কৃতিচর্চার জীবনশিল্পী সংস্কৃতি কেন্দ্র সামালী, জোকা, কলকাতা থেকে ২০০৭, রবীন্দ্র ভারতী বিশ্ববিদ্যালয়ের'ফ্যাকাল্টি-অফ-ভিসুয়াল-আর্টস' বিভাগ থেকে ২০১৫ সালে পশ্চিমবঙ্গ সরকারের আদিবাসী উন্নয়ন দপ্তর আয়োজিত 'চা ও আদিবাসী উৎসব' থেকে ২০১৭ সালে এবং সম্প্রীতি আকাদেমি, কলকাতা থেকে পেয়েছেন বিশেষ পুরস্কার ও সংবর্ধনা। সম্প্রতি (২০১৯) ঢাকা বাংলাদেশ রাইটার্স ইন্টারন্যাশনাল থেকে সাহিত্যচর্চার জন্য এবং 'বাংলাদেশ-নেপাল মৈত্রী উৎসব' থেকে পেয়েছেন। বিশেষ সম্মান ও পুরস্কার। সংবর্ধিত হয়েছেন বাংলাদেশ লেখক পরিষদ থেকেও। পশ্চিমবঙ্গ সরকারের 'বঙ্গরত্ন' সম্মানে সম্মানিত হয়েছেন ২০২১ সালে। বিষ্ণুপুর, বাঁকুড়া থেকে পেয়েছেন 'টেরাকোটা' সম্মান, ২০২২ সালে। এ ছাড়াও পেয়েছেন বহু সম্মান ও পুরস্কার। অংশগ্রহণ করেছেন অনেক জাতীয় ও আন্তর্জাতিক আলোচনা সভায়। বর্তমানে অবসরপ্রাপ্ত গ্রন্থাগারকর্মী।</p><br>
                            <p>প্রমোদ নাথের প্রকাশিত গ্রন্থের তালিকা:-</p><br>

                            <p class="mytext text-dark">
                                ০১। ডুয়ার্সের জনজাতি- ২০০২

                                ০২। ডুয়ার্সের আদিবাসী সাহিত্যচর্চা- ২০০৫

                                 ০৩। প্রান্তীয় উত্তরবঙ্গের লোককবি-২০০৫

                                    ০৪। প্রান্তীয় উত্তরবঙ্গের জনজাতি (১ম সংস্করণ)-২০০৫

                                    ০৫। মেঘ মেয়ে (কাব্যগ্রন্থ)-২০০৫

                                    ০৬। মেচ সংস্কৃতির আঙিনায়- ২০০৬

                                    ০৭। উত্তরবঙ্গের আদিবাসী জনজীবনে বিয়ের গান- ২০০৭

                                    ০৮। ডুয়ার্সে নেপালি সাহিত্যচর্চা- ২০০৮

                                    ০৯। মেচ সমাজ ও সংস্কৃতি- ২০০৮

                                    ১০। উত্তরবঙ্গের আদিবাসী জনজীবনে পূজাপার্বণ- ২০০৮

                                    ১১। উত্তরবঙ্গের লোকজীবনে প্রচলিত ধাঁধা-২০০৯

                                    ১২। উত্তরবঙ্গ দর্পণ, ১ম খণ্ড (সম্পাদিত)- ২০০৯

                                    ১৩। উত্তরবঙ্গ দর্পণ, ২য় খণ্ড (সম্পাদিত)- ২০১০

                                    ১৪। লোকায়ত আঙিনায় উত্তরবঙ্গ (সম্পাদিত) - ২০১০

                                    ১৫। তামাঙ- ২০১১

                                    ১৬। উত্তরবঙ্গের আদিবাসী পরিচয়- ২০১১

                                    ১৭। উত্তরবঙ্গের আঞ্চলিক শব্দকোষ (সম্পাদিত)- ২০১১

                                    ১৮। উত্তরবঙ্গের আদিবাসী উৎসব-২০১২

                                    ১৯। উত্তরবঙ্গের আদিবাসী মেচ সমাজ ও সংস্কৃতি- ২০১২

                                    ২০। মগর সমাজ ও সংস্কৃতি- ২০১৩

                                    ২১। উত্তরের রবীন্দ্রনাথ (সম্পাদিত) ২০১৩ ২২। উত্তরের আদিবাসী লোককথা ২০১৪

                                    ২৩। উত্তরের লোকজীবনে লোকঔষধী- ২০১৪

                                    ২৪। উত্তরবঙ্গের ভাষা সমীক্ষা ২০১৫

                                    ২৫। প্রান্তীয় উত্তরবঙ্গের জনজাতি ২০১৫ (২য় সংস্করণ)

                                    ২৬। উত্তরবঙ্গের লোকজীবনে খাদ্য ও পানীয় ২০১৫

                                    ২৭। উত্তরের আদিম আদিবাসী টোটো সম্প্রদায়ের লোকপ্রযুক্তি - ২০১৬

                                    ২৮। উত্তরের আদিবাসী শিল্প-সংস্কৃতির নানা দিগন্ত ২০১৬

                                    ২৯। এক আকাশ অনেক মানুষ (জনজাতির কবিতা সংকলন)- ২০১৬

                                    ৩০। একুশ শতকে টোটো সমাজ ও সংস্কৃতি - ২০১৭

                                    ৩১। উত্তরবঙ্গের নেপালি সমাজ ও সংস্কৃতি - ২০১৭

                                    ৩২। জন্ম-মৃত্যু-বিবাহের আলোকে উত্তরবঙ্গের আদিবাসী সমাজ ২০১৭

                                    ৩৩। উত্তরের লোকসংস্কৃতির নানা দিগন্ত (সম্পাদিত) - ২০১৭

                                    ৩৪। শেরপা সমাজ ও সংস্কৃতি- ২০১৮

                                    ৩৫। লিমু সমাজ ও সংস্কৃতি- ২০১৮

                                    ৩৬। উত্তরের আদিবাসী নৃত্যচর্চা - ২০১৮

                                    ৩৭। ইতিকথায় আলিপুরদুয়ার (সম্পাদিক) ২০১৮

                                    ৩৮। অসুর সমাজ ও সংস্কৃতি - ২০১৯

                                    ৩৯। আদিম আদিবাসী টোটো লোককথা ২০১৯

                                    ৪০। মাহালি সমাজ ও সংস্কৃতি - ২০১৯

                                    ৪১। পশ্চিমবঙ্গের আদিম আদিবাসী পরিচয় - ২০১৯

                                    ৪২। মগর সমাজ ও সংস্কৃতি (হিন্দি অনুবাদ) ২০১৯

                                    ৪৩। শেরপা সমাজ ও সংস্কৃতি (হিন্দি অনুবাদ) - ২০১৯

                                    ৪৪। শেরপা সমাজ ও সংস্কৃতি (নেপালি অনুবাদ) - ২০২০

                                    ৪৫। প্রান্তীয় উত্তরবঙ্গের লোকনাটক ২০২১

                                    ৪৬। আদিম আদিবাসী টোটো ২০২১

                                    ৪৭। স্বাধীনতা আন্দোলনে উত্তরবঙ্গের আদিবাসী সমাজ - ২০২১

                                    ৪৮। আদিবাসী চা-শ্রমিকের জন্ম-মৃত্যু ও বিবাহ প্রথা - ২০২১

                                    ৪৯। উত্তরের আদিবাসী মুখোশ-শিল্প - ২০২১

                                    ৫০। আদিবাসী মেচ লোককথা - ২০২২

                                    ৫১। আদিম জনজাতি টোটো সমাজ জীবনে নারী- ২০২৩

                                    ৫২। নীলকান্ত মুখোপাধ্যায় স্মারক গ্রন্থ (সম্পাদিত) - ২০২৩

                                    ৫৩। আপন কথা (আদিবাসী প্রবন্ধ সংকলন) / (সম্পাদিত) - ২০২৪

                                    ৫৪। দুই বাংলার লোককথা, (ভারত-বাংলাদেশ) / (সম্পাদিত) - ২০২৪
                            </p>
                        </div>
            </div>
            <div class="col order-first">
            <img src="<?php echo get_template_directory_uri();?>/images/dipak-kr.jpg" alt="aponkotha" class="img-thumbnail">
            <br>
            <p>ড. দীপক কুমার রায়</p>
            <p>প্রধান উপদেষ্টা -উপাচার্য, রায়গঞ্জ বিশ্ববিদ্যালয় </p>
            </div>
        </div><br>
<?php get_footer();?>
</body>
<script src="<?php echo get_template_directory_uri();?>/js/loadmore.js"></script>

