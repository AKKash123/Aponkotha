<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	
<body>
<div class="first-nav container-fluid">
    
    <h3 class="text-primary"style="margin-left:480px;margin-top:25px;">আলকবর্তিকা</h3>
    <img class="img-nav" src="<?php echo get_template_directory_uri();?>/images/logo.jpeg" alt="">আপনকথা
    <ul class="nav-ul">
        <li class="nav-text">ডুয়ার্সের বই আন্দোলন গড়ে তোলা</li><br>
        <li class="nav-text">ডুয়ার্সের নৃত্য ভাষা-সাহিত্য ইতিহাস সংস্কৃতি চর্চা ও সংরক্ষণ</li>
    </ul>  
</div><br>
<div class="container navbar-container container-fluid">
				<div class="top-social">
					<ul id="top-social-menu">
                    <li><i class="fa fa-phone"></i> ৯৮৩২৫৬৩০১৪</li>
					<li><i class="fa fa-home"></i> বইমহল চতুর্থ তলা, আলিপুরদুয়ার আদালত, আলিপুরদুয়ার, পশ্চিমবঙ্গ, ভারত</li>
                    <li><i class="fa fa-book"></i>রেজিস্ট্রেশন নং ঃ S0034893 of 2022-2023</li>
					</ul>
				</div>
			</div>
<br>
<?php get_header();?>


</body>

