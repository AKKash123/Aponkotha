
<!DOCTYPE html>
<html lang="en">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="aponkotha alipurduar aponkotha">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <body>
        <?php get_header();?>
        <div class="container container-fluid">
            <div class="row">
                <h4 class="text-primary" style="margin-left: 41px; margin-top: 14px;"><?php the_title();?></h4><br><br>
            </div>
            <div class="col-md-6">
                    <?php the_content();?>
            </div><br>
        </div>
        <?php get_footer();?>
    </body>
</html>
