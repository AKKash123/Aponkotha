<head><link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico"><br></head>

<?php get_header();?>

    <div class="row">
        <h4 class="text-primary" style="margin-left: 41px; margin-top: 14px;"><?php the_title();?></h4><br><br>
    </div>
    <div class="col-md-6">
            <?php the_content();?>
    </div>
    


<?php get_footer();?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css">