<!DOCTYPE html>
<html lang="en">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <body>
        <?php get_header();?>
        <br>
        
        <?php  $imagepath  = wp_get_attachment_image_src(get_post_thumbnail_id(),'small'); ?>
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <h3><span><?php the_title();?></span></h3><br>
                    <p class="text-success"><?php echo get_the_date();?></p><br>
                    <h5 class="text-danger"><?php the_author_meta('display_name', 1); ?></h5>
                </div>
                <div class="col-4">
                    <img class="img-fluid"src="<?php echo $imagepath[0]; ?>">
                </div>
                <div class="col-6">
                    <p class="mycontent text-info"><?php the_content();?></p>
                </div>
            </div>
        </div>
        <br>
        <?php get_footer();?>
    </body>
</html>