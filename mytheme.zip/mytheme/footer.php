<footer class="footer">
        <div class="footer_top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-md-6 col-lg-4 ">
                        <div class="footer_widget">
                            <div class="footer_logo">
                                <a href="#home">
                                    <img  width="40px" height="40px" src="<?php echo get_template_directory_uri(); ?>/images/logo.jpeg" alt="">
                                </a>
                            </div>
                            <p class="address_text">বইমহল চতুর্থ তলা, আলিপুরদুয়ার আদালত, আলিপুরদুয়ার, পশ্চিমবঙ্গ, ভারত
                            </p>
                            <div class="socail_links">
                                <ul>
                                    <li>
                                        <a href="#">
                                            <i class="ti-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="ti-twitter-alt"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-dribbble"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-instagram"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-2 col-md-6 col-lg-4">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                                Navigation
                            </h3>
                            <ul class="links">
                            <a class="nav-item nav-link" href="#">মূলপাতা</a>
                            <a class="nav-item nav-link" href="#">পরিচিতি</a>
                            <a class="nav-item nav-link" href="#">আগামী কার্যক্রম</a>
                            <a class="nav-item nav-link " href="#">মিডিয়া</a>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 col-lg-4">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                            যোগাযোগ
                            </h3>
                            <div class="col-lg-4 col-md-6">
                                <?php echo do_shortcode('[contact-form-7 id="18b0798" title="Contact form 1"]') ;?>
                            </div>
                            <div class="contacts">
                                <p> <i class="fa fa-phone"></i> 9832563014 <br>
                                <i class="fa fa-envelope"></i> boimahal@gmail.com
                                </p>

                            </div>
                        </div>
                        
                    </div>
                    
                    
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text">
            <div class="container">
                <div class="row">
                    <div class="bordered_1px "></div>
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                        <p>
                            <a href="<?php echo get_template_directory_uri();?>/terms.pdf" download > Download  Terms & Condition</a>
                            Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script> All rights reserved | This
                            template is made with <i class="ti-heart" aria-hidden="true"></i> by <a
                                href="#" target="_blank">Ewebsolution</a>
                            
                        </p>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
   