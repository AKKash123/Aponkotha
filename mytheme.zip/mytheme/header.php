<header>
	
<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>আপনকথা</title>
        
       <meta name="description" content="A NGO of Alipurduar,empowering communities through education - Join our NGO's mission to provide equal educational opportunities for all.Bridging the education gap - Support our NGO's efforts in providing inclusive education for all communities.">
       <meta property=”og:type” content=”website” />
       <meta poperty='og:url'content="https://aponkotha.com/"/>
        <meta name="keywords" content="aponkotha-alipurduar,aponkotha, aponkothango, aponkotha,Alipurduar, Alipurduar-ngo,ngo full form,ngo,ngo near me,ngo in india,ngo website,Aponkotha,aponkotha,aponkotha-ngo,aponkotha ngo,আপন কথা: অবনীন্দ্রনাথ ঠাকুর,Apon Katha - Abanindranath Tagore,Apon Kotha,আপনকথা,ngo in Alipurduar,Alipurduar ngo">
        <meta http-equiv="refresh" content="1800">
        <meta poperty="og:title" content="aponkotha"/>
        <meta poperty="description" content="A NGO of Alipurduar,empowering communities through education - Join our NGO's mission to provide equal educational opportunities for all.Bridging the education gap - Support our NGO's efforts in providing inclusive education for all communities."</meta>
        <meta poperty='og:image' content="images/logo.jpeg"/>
        <meta poperty="og:image:width" content='1200' />
        <meta poperty="og:image:height" content='627' />
        <meta poperty='og:tag' content="aponkotha"/>
        <meta name="author" content="aponkotha,আপনকথা">
       <meta name="google-site-verification" content="3TPswDJuAUsrKyktCf1Js6mgTZbVeqFQ-Oba1Us_jiE" />
       <meta name="cname" content="zrrfhaonj2wj">
       <meta name="cname" content="gv-iard2zsjinprfh.dv.googlehosted.com">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <!-- <link rel="manifest" href="site.webmanifest"> -->
    	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <!-- Place favicon.ico in the root directory -->
	<nav class="navbar navbar-expand-lg navbar-light bg-warning">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			<div class="navbar-nav">
            <a class="nav-item nav-link" href="/aaponkotha">মূলপাতা</a>
				<?php wp_nav_menu(array('theme_location'=>'primary-menu','menu_class'=>'my-nav '))?>
			</div>
		</div>
	</nav>
	</header>

	
	<!-- CSS here -->
    
	<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/style.css"> 
	<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/themify-icons.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<!--contact js-->
    <script src="<?php echo get_template_directory_uri();?>/js/contact.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/jquery.ajaxchimp.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/jquery.form.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/jquery.validate.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/mail-script.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/datahandel.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/main.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/media.js"></script>
	<script src="<?php echo get_template_directory_uri();?>/js/ajax-form.js"></script>
	
	</section>
    
