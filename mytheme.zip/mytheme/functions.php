 <?php
function redirect_to_alok()
{
    if(is_page('53')){
        wp_redirect(site_url('/আলকবর্তিকা'),301);
        exit();
    }
}
add_action('template_redirect','redirect_to_alok');
?> 