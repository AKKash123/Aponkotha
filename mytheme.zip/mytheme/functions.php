 <?php
    register_nav_menus(
        array('primary-menu'=>'Top Menu')
    )
?> 